# AnimeVerse Backend **v1.0.0** — planned foundation complete

```bash
npm install
npm run db:migrate   # 001–005
npm run db:seed
npm start            # :8787
```

| Script | Purpose |
|--------|---------|
| `npm run test:api` | Smoke suite |
| `npm run test:load` | Concurrent load test |
| `npm run db:backup` | SQLite snapshot |

Demo: `demo@animeverse.local` / `demo1234`  
OpenAPI: `/v1/openapi.json` · Metrics: `/v1/metrics`  
Runbook: `docs/RUNBOOK.md`

**Stack:** Express · SQLite (`node:sqlite`) · JWT · Zod  
**Optional:** Redis (`REDIS_URL` + `ioredis`) · Postgres DDL under `migrations/postgres/`
