import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.js';
import { requireAuth, optionalAuth } from '../middleware/auth.js';
import { newId } from '../utils/auth.js';

const router = Router();

function assertProfileOwned(userId, profileId) {
  return getDb()
    .prepare('SELECT id FROM profiles WHERE id = ? AND user_id = ?')
    .get(profileId, userId);
}

/** Post activity event */
router.post('/profiles/:profileId/activity', requireAuth, (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const schema = z.object({
    type: z.enum(['watched', 'rated', 'watchlist', 'started', 'finished', 'custom']),
    titleId: z.string().optional(),
    meta: z.record(z.any()).optional(),
    visibility: z.enum(['public', 'friends', 'private']).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }
  const { type, titleId, meta, visibility } = parsed.data;
  const id = newId('act');
  getDb()
    .prepare(
      `INSERT INTO activity_events (id, actor_profile_id, type, title_id, meta_json, visibility)
       VALUES (?, ?, ?, ?, ?, ?)`
    )
    .run(
      id,
      req.params.profileId,
      type,
      titleId || null,
      JSON.stringify(meta || {}),
      visibility || 'friends'
    );
  res.status(201).json({ ok: true, id });
});

/** Feed: public + own events (friends graph not fully built — demo feed) */
router.get('/feed', optionalAuth, (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 30, 50);
  const items = getDb()
    .prepare(
      `SELECT a.id, a.type, a.title_id AS titleId, t.title AS titleName,
              a.actor_profile_id AS profileId, p.name AS profileName,
              a.meta_json AS metaJson, a.visibility, a.created_at AS createdAt
       FROM activity_events a
       JOIN profiles p ON p.id = a.actor_profile_id
       LEFT JOIN titles t ON t.id = a.title_id
       WHERE a.visibility = 'public'
          OR a.visibility = 'friends'
       ORDER BY a.created_at DESC LIMIT ?`
    )
    .all(limit)
    .map((r) => {
      let meta = {};
      try {
        meta = JSON.parse(r.metaJson || '{}');
      } catch {
        /* */
      }
      return {
        id: r.id,
        type: r.type,
        titleId: r.titleId,
        titleName: r.titleName,
        profileId: r.profileId,
        profileName: r.profileName,
        meta,
        visibility: r.visibility,
        createdAt: r.createdAt,
      };
    });
  res.json({ items });
});

/** Franchise / relation graph for a title */
router.get('/titles/:id/timeline', (req, res) => {
  const title = getDb()
    .prepare('SELECT id, title, year, status FROM titles WHERE id = ?')
    .get(req.params.id);
  if (!title) return res.status(404).json({ error: 'Title not found' });

  const outbound = getDb()
    .prepare(
      `SELECT r.to_title_id AS id, t.title, t.year, r.relation
       FROM title_relations r JOIN titles t ON t.id = r.to_title_id
       WHERE r.from_title_id = ?`
    )
    .all(req.params.id);
  const inbound = getDb()
    .prepare(
      `SELECT r.from_title_id AS id, t.title, t.year, r.relation
       FROM title_relations r JOIN titles t ON t.id = r.from_title_id
       WHERE r.to_title_id = ?`
    )
    .all(req.params.id);

  res.json({
    title,
    relations: { outbound, inbound },
  });
});



/** Follow another profile */
router.post('/profiles/:profileId/follow', requireAuth, (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const targetId = req.body?.targetProfileId;
  if (!targetId) return res.status(400).json({ error: 'targetProfileId required' });
  if (targetId === req.params.profileId) {
    return res.status(400).json({ error: 'Cannot follow yourself' });
  }
  const target = getDb().prepare('SELECT id FROM profiles WHERE id = ?').get(targetId);
  if (!target) return res.status(404).json({ error: 'Target profile not found' });
  getDb()
    .prepare(
      `INSERT OR IGNORE INTO follows (follower_profile_id, following_profile_id) VALUES (?, ?)`
    )
    .run(req.params.profileId, targetId);
  res.status(201).json({ ok: true, following: targetId });
});

router.delete('/profiles/:profileId/follow/:targetProfileId', requireAuth, (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  getDb()
    .prepare(
      `DELETE FROM follows WHERE follower_profile_id = ? AND following_profile_id = ?`
    )
    .run(req.params.profileId, req.params.targetProfileId);
  res.json({ ok: true });
});

router.get('/profiles/:profileId/following', (req, res) => {
  const items = getDb()
    .prepare(
      `SELECT p.id, p.name, p.avatar_color AS avatarColor, f.created_at AS since
       FROM follows f JOIN profiles p ON p.id = f.following_profile_id
       WHERE f.follower_profile_id = ? ORDER BY f.created_at DESC`
    )
    .all(req.params.profileId);
  res.json({ items });
});

router.get('/profiles/:profileId/followers', (req, res) => {
  const items = getDb()
    .prepare(
      `SELECT p.id, p.name, p.avatar_color AS avatarColor, f.created_at AS since
       FROM follows f JOIN profiles p ON p.id = f.follower_profile_id
       WHERE f.following_profile_id = ? ORDER BY f.created_at DESC`
    )
    .all(req.params.profileId);
  res.json({ items });
});

/** Friends feed: activity from profiles you follow + own */
router.get('/profiles/:profileId/friends-feed', requireAuth, (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const limit = Math.min(Number(req.query.limit) || 30, 50);
  const items = getDb()
    .prepare(
      `SELECT a.id, a.type, a.title_id AS titleId, t.title AS titleName,
              a.actor_profile_id AS profileId, p.name AS profileName,
              a.meta_json AS metaJson, a.created_at AS createdAt
       FROM activity_events a
       JOIN profiles p ON p.id = a.actor_profile_id
       LEFT JOIN titles t ON t.id = a.title_id
       WHERE a.actor_profile_id = ?
          OR a.actor_profile_id IN (
            SELECT following_profile_id FROM follows WHERE follower_profile_id = ?
          )
       ORDER BY a.created_at DESC LIMIT ?`
    )
    .all(req.params.profileId, req.params.profileId, limit)
    .map((r) => {
      let meta = {};
      try { meta = JSON.parse(r.metaJson || '{}'); } catch { /* */ }
      return {
        id: r.id, type: r.type, titleId: r.titleId, titleName: r.titleName,
        profileId: r.profileId, profileName: r.profileName, meta, createdAt: r.createdAt,
      };
    });
  res.json({ items });
});

export default router;

