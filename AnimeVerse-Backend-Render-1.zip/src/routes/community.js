import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.js';
import { requireAuth, optionalAuth } from '../middleware/auth.js';
import { newId } from '../utils/auth.js';

const router = Router();

function assertProfileOwned(userId, profileId) {
  return getDb()
    .prepare('SELECT id FROM profiles WHERE id = ? AND user_id = ?')
    .get(profileId, userId);
}

/** List reviews for a title (spoilers redacted unless reveal=1) */
router.get('/titles/:titleId/reviews', optionalAuth, (req, res) => {
  const reveal = req.query.reveal === '1' || req.query.reveal === 'true';
  const rows = getDb()
    .prepare(
      `SELECT r.id, r.profile_id AS profileId, p.name AS profileName, r.rating, r.body,
              r.has_spoilers AS hasSpoilers, r.created_at AS createdAt
       FROM reviews r
       JOIN profiles p ON p.id = r.profile_id
       WHERE r.title_id = ? AND r.status = 'visible'
       ORDER BY r.created_at DESC LIMIT 50`
    )
    .all(req.params.titleId);

  const items = rows.map((r) => ({
    ...r,
    body:
      r.hasSpoilers && !reveal
        ? '[Spoiler protected — set ?reveal=1 to view]'
        : r.body,
    spoilerHidden: !!(r.hasSpoilers && !reveal),
  }));

  res.json({ items, count: items.length });
});

router.post('/profiles/:profileId/reviews', requireAuth, (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const schema = z.object({
    titleId: z.string().min(1),
    rating: z.number().int().min(1).max(10),
    body: z.string().max(4000).optional(),
    hasSpoilers: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }
  const { titleId, rating, body, hasSpoilers } = parsed.data;
  const title = getDb().prepare('SELECT id FROM titles WHERE id = ?').get(titleId);
  if (!title) return res.status(404).json({ error: 'Title not found' });

  const id = newId('rev');
  getDb()
    .prepare(
      `INSERT INTO reviews (id, profile_id, title_id, rating, body, has_spoilers)
       VALUES (?, ?, ?, ?, ?, ?)
       ON CONFLICT(profile_id, title_id) DO UPDATE SET
         rating = excluded.rating,
         body = excluded.body,
         has_spoilers = excluded.has_spoilers,
         updated_at = datetime('now')`
    )
    .run(id, req.params.profileId, titleId, rating, body || null, hasSpoilers ? 1 : 0);

  res.status(201).json({ ok: true, id, titleId, rating });
});

router.delete('/profiles/:profileId/reviews/:titleId', requireAuth, (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  getDb()
    .prepare('DELETE FROM reviews WHERE profile_id = ? AND title_id = ?')
    .run(req.params.profileId, req.params.titleId);
  res.json({ ok: true });
});

/** Radar alert subscribe/unsubscribe */
router.post('/profiles/:profileId/radar', requireAuth, (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const titleId = req.body?.titleId;
  if (!titleId) return res.status(400).json({ error: 'titleId required' });
  const title = getDb().prepare('SELECT id FROM titles WHERE id = ?').get(titleId);
  if (!title) return res.status(404).json({ error: 'Title not found' });

  const id = newId('radar');
  getDb()
    .prepare(
      `INSERT INTO radar_alerts (id, profile_id, title_id, enabled) VALUES (?, ?, ?, 1)
       ON CONFLICT(profile_id, title_id) DO UPDATE SET enabled = 1`
    )
    .run(id, req.params.profileId, titleId);
  res.status(201).json({ ok: true, titleId });
});

router.delete('/profiles/:profileId/radar/:titleId', requireAuth, (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  getDb()
    .prepare('DELETE FROM radar_alerts WHERE profile_id = ? AND title_id = ?')
    .run(req.params.profileId, req.params.titleId);
  res.json({ ok: true });
});

/** Genre preferences for recommendations */
router.put('/profiles/:profileId/preferences', requireAuth, (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const genres = Array.isArray(req.body?.genres) ? req.body.genres : [];
  const db = getDb();
  db.prepare('DELETE FROM profile_preferences WHERE profile_id = ?').run(req.params.profileId);
  const ins = db.prepare(
    `INSERT OR IGNORE INTO profile_preferences (profile_id, genre_id) VALUES (?, ?)`
  );
  for (const g of genres.slice(0, 20)) {
    const row = db.prepare('SELECT id FROM genres WHERE id = ? OR name = ?').get(g, g);
    if (row) ins.run(req.params.profileId, row.id);
  }
  res.json({ ok: true, genres });
});

router.get('/profiles/:profileId/preferences', requireAuth, (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const items = getDb()
    .prepare(
      `SELECT g.id, g.name FROM profile_preferences pp
       JOIN genres g ON g.id = pp.genre_id WHERE pp.profile_id = ?`
    )
    .all(req.params.profileId);
  res.json({ genres: items });
});

export default router;
