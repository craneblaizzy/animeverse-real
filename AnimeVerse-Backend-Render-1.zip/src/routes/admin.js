import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.js';
import { requireAuth } from '../middleware/auth.js';
import { newId } from '../utils/auth.js';
import { runMaintenance, healthDeep } from '../services/jobs.js';

const router = Router();

/** Demo admin gate: email ends with @animeverse.local or role=admin */
function requireAdmin(req, res, next) {
  requireAuth(req, res, () => {
    const user = getDb()
      .prepare('SELECT id, email, display_name AS displayName FROM users WHERE id = ?')
      .get(req.user.sub);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });
    const isAdmin =
      user.email?.endsWith('@animeverse.local') ||
      user.email === 'demo@animeverse.local';
    if (!isAdmin) {
      return res.status(403).json({ error: 'AdminOnly', message: 'Demo admin requires @animeverse.local email' });
    }
    req.admin = user;
    next();
  });
}

router.use(requireAdmin);

router.get('/stats', (_req, res) => {
  res.json(healthDeep());
});

router.post('/jobs/maintenance', (_req, res) => {
  res.json({ result: runMaintenance() });
});

router.get('/titles', (req, res) => {
  const includeUnpublished = req.query.all === '1';
  const sql = includeUnpublished
    ? `SELECT id, title, year, status, rating, published, updated_at AS updatedAt FROM titles ORDER BY updated_at DESC LIMIT 100`
    : `SELECT id, title, year, status, rating, published, updated_at AS updatedAt FROM titles WHERE published = 1 ORDER BY updated_at DESC LIMIT 100`;
  res.json({ items: getDb().prepare(sql).all() });
});

router.patch('/titles/:id', (req, res) => {
  const schema = z.object({
    title: z.string().min(1).optional(),
    status: z.string().optional(),
    rating: z.number().min(0).max(10).optional(),
    published: z.boolean().optional(),
    description: z.string().optional(),
    year: z.number().int().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }
  const row = getDb().prepare('SELECT id FROM titles WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Title not found' });

  const d = parsed.data;
  const sets = [];
  const params = [];
  if (d.title != null) {
    sets.push('title = ?');
    params.push(d.title);
  }
  if (d.status != null) {
    sets.push('status = ?');
    params.push(d.status);
  }
  if (d.rating != null) {
    sets.push('rating = ?');
    params.push(d.rating);
  }
  if (d.published != null) {
    sets.push('published = ?');
    params.push(d.published ? 1 : 0);
  }
  if (d.description != null) {
    sets.push('description = ?');
    params.push(d.description);
  }
  if (d.year != null) {
    sets.push('year = ?');
    params.push(d.year);
  }
  if (!sets.length) return res.status(400).json({ error: 'No fields to update' });
  sets.push(`updated_at = datetime('now')`);
  params.push(req.params.id);
  getDb().prepare(`UPDATE titles SET ${sets.join(', ')} WHERE id = ?`).run(...params);
  res.json({ ok: true, id: req.params.id });
});

router.post('/titles', (req, res) => {
  const schema = z.object({
    id: z.string().min(2).max(64).optional(),
    title: z.string().min(1),
    type: z.enum(['series', 'movie']).optional(),
    year: z.number().int().optional(),
    status: z.string().optional(),
    rating: z.number().optional(),
    episodes: z.number().int().optional(),
    description: z.string().optional(),
    studio: z.string().optional(),
    published: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }
  const d = parsed.data;
  const id = d.id || newId('title').replace(/_/g, '-').slice(0, 40);
  getDb()
    .prepare(
      `INSERT INTO titles (id, title, type, year, status, rating, episodes, description, studio_name, published)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      id,
      d.title,
      d.type || 'series',
      d.year ?? null,
      d.status || 'Completed',
      d.rating ?? 0,
      d.episodes ?? 1,
      d.description ?? null,
      d.studio ?? null,
      d.published === false ? 0 : 1
    );
  res.status(201).json({ ok: true, id });
});

router.post('/titles/:id/episodes', (req, res) => {
  const schema = z.object({
    seasonNumber: z.number().int().min(1).default(1),
    episodeNumber: z.number().int().min(1),
    name: z.string().optional(),
    runtime: z.number().int().optional(),
    introStartMs: z.number().int().optional(),
    introEndMs: z.number().int().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }
  const title = getDb().prepare('SELECT id FROM titles WHERE id = ?').get(req.params.id);
  if (!title) return res.status(404).json({ error: 'Title not found' });
  const d = parsed.data;
  const id = `${req.params.id}-s${d.seasonNumber}e${d.episodeNumber}`;
  getDb()
    .prepare(
      `INSERT OR REPLACE INTO episodes (id, title_id, season_number, episode_number, name, runtime, intro_start_ms, intro_end_ms)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      id,
      req.params.id,
      d.seasonNumber,
      d.episodeNumber,
      d.name || `Episode ${d.episodeNumber}`,
      d.runtime ?? 24,
      d.introStartMs ?? null,
      d.introEndMs ?? null
    );
  res.status(201).json({ ok: true, id });
});

router.post('/titles/:id/relations', (req, res) => {
  const schema = z.object({
    toTitleId: z.string(),
    relation: z.enum(['sequel', 'prequel', 'spinoff', 'related', 'same_franchise']).default('related'),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }
  const { toTitleId, relation } = parsed.data;
  getDb()
    .prepare(
      `INSERT OR IGNORE INTO title_relations (from_title_id, to_title_id, relation) VALUES (?, ?, ?)`
    )
    .run(req.params.id, toTitleId, relation);
  res.status(201).json({ ok: true });
});

router.get('/reviews/moderation', (_req, res) => {
  const items = getDb()
    .prepare(
      `SELECT r.id, r.title_id AS titleId, r.profile_id AS profileId, r.rating, r.body,
              r.has_spoilers AS hasSpoilers, r.status, r.created_at AS createdAt
       FROM reviews r WHERE r.status = 'flagged' OR r.moderated = 0
       ORDER BY r.created_at DESC LIMIT 50`
    )
    .all();
  res.json({ items });
});

router.patch('/reviews/:id', (req, res) => {
  const status = req.body?.status;
  if (!['visible', 'hidden', 'flagged'].includes(status)) {
    return res.status(400).json({ error: 'status must be visible|hidden|flagged' });
  }
  getDb()
    .prepare(`UPDATE reviews SET status = ?, moderated = 1, updated_at = datetime('now') WHERE id = ?`)
    .run(status, req.params.id);
  res.json({ ok: true });
});

router.get('/users', (_req, res) => {
  const items = getDb()
    .prepare(
      `SELECT id, email, display_name AS displayName, status, created_at AS createdAt FROM users ORDER BY created_at DESC LIMIT 100`
    )
    .all();
  res.json({ items });
});

router.patch('/users/:id', (req, res) => {
  const status = req.body?.status;
  if (!['active', 'suspended', 'deleted'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status' });
  }
  getDb().prepare('UPDATE users SET status = ?, updated_at = datetime("now") WHERE id = ?').run(status, req.params.id);
  res.json({ ok: true });
});



router.get('/titles/:id/rights', (req, res) => {
  const row = getDb().prepare('SELECT * FROM title_rights WHERE title_id = ?').get(req.params.id);
  res.json({ rights: row || null });
});

router.put('/titles/:id/rights', (req, res) => {
  const {
    territory = 'WW',
    licenseStart,
    licenseEnd,
    licensor,
    windowType = 'svod',
    exclusivity = false,
    notes,
  } = req.body || {};
  getDb()
    .prepare(
      `INSERT INTO title_rights (title_id, territory, license_start, license_end, licensor, window_type, exclusivity, notes, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
       ON CONFLICT(title_id) DO UPDATE SET
         territory = excluded.territory,
         license_start = excluded.license_start,
         license_end = excluded.license_end,
         licensor = excluded.licensor,
         window_type = excluded.window_type,
         exclusivity = excluded.exclusivity,
         notes = excluded.notes,
         updated_at = datetime('now')`
    )
    .run(
      req.params.id,
      territory,
      licenseStart || null,
      licenseEnd || null,
      licensor || null,
      windowType,
      exclusivity ? 1 : 0,
      notes || null
    );
  res.json({ ok: true });
});

export default router;

