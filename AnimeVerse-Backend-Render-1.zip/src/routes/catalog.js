import { Router } from 'express';
import {
  charactersForTitle,
  getStudio,
  getTitle,
  listGenres,
  listStudios,
  listTitles,
  radarWeek,
  recommendations,
  railsCached,
  searchFacets,
} from '../services/catalog.js';
import {
  searchAnime,
  getAnime,
  getTrending,
  getAiring,
  getSeasonal,
  getUpcoming,
  getRecommendationsFor,
  liveRails,
  providerStatus,
  metadataMode,
} from '../providers/manager.js';
import { optionalAuth, requireAuth } from '../middleware/auth.js';
import { getDb } from '../db/connection.js';
import { signPlaybackToken } from '../utils/auth.js';

const router = Router();

router.get('/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'animeverse-api',
    version: '1.1.0',
    metadataMode: metadataMode(),
    providers: providerStatus(),
    time: new Date().toISOString(),
  });
});

router.get('/meta/status', (_req, res) => {
  res.json(providerStatus());
});

router.get('/genres', (_req, res) => {
  res.json({ genres: listGenres() });
});

router.get('/studios', (_req, res) => {
  res.json({ studios: listStudios() });
});

router.get('/studios/:id', (req, res) => {
  const studio = getStudio(req.params.id);
  if (!studio) return res.status(404).json({ error: 'Studio not found' });
  res.json({ studio });
});

/** Local DB catalog (demo seed) — always available */
router.get('/titles', (req, res) => {
  const {
    status, genre, q, year, studio, type, tone, pacing, minRating, limit, offset, sort,
  } = req.query;
  const items = listTitles({
    status, genre, q, year, studio, type, tone, pacing, minRating, limit, offset, sort,
  });
  res.json({ items, count: items.length, mode: 'DEMO', source: 'local' });
});

/** Unified search: providers → normalize → fallback local */
router.get('/search', async (req, res) => {
  const q = req.query.q || '';
  const limit = req.query.limit || 24;
  try {
    const result = await searchAnime(String(q), { limit: Number(limit) || 24 });
    const facets =
      result.mode === 'DEMO' || result.source === 'demo-fallback'
        ? searchFacets(q)
        : buildLiveFacets(result.items);
    res.json({
      items: result.items,
      count: result.items.length,
      facets,
      mode: result.mode,
      source: result.source,
      upstreamErrors: result.upstreamErrors,
    });
  } catch (e) {
    const local = listTitles({ q, limit: limit || 24 });
    res.json({
      items: local,
      count: local.length,
      facets: searchFacets(q),
      mode: 'DEMO',
      source: 'demo-fallback',
      error: { code: e.code || 'SEARCH_ERROR', message: e.message },
    });
  }
});

function buildLiveFacets(items) {
  const genres = {};
  const years = {};
  for (const t of items || []) {
    for (const g of t.genres || []) genres[g] = (genres[g] || 0) + 1;
    if (t.year) years[t.year] = (years[t.year] || 0) + 1;
  }
  const toArr = (obj) =>
    Object.entries(obj)
      .map(([value, count]) => ({ value, count }))
      .sort((a, b) => b.count - a.count);
  return { total: items?.length || 0, genres: toArr(genres), years: toArr(years) };
}

router.get('/titles/:id', async (req, res) => {
  try {
    const result = await getAnime(req.params.id);
    if (!result.title) {
      return res.status(404).json({
        error: result.error?.code || 'Title not found',
        message: result.error?.message,
      });
    }
    const title = result.title;
    if (!title.characters?.length) {
      try {
        title.characters = charactersForTitle(req.params.id);
      } catch {
        title.characters = title.characters || [];
      }
    }
    res.json({ title, mode: result.mode, source: result.source });
  } catch (e) {
    res.status(502).json({
      error: {
        code: e.code || 'UPSTREAM_UNAVAILABLE',
        message: e.message || 'Anime metadata service temporarily unavailable',
        requestId: req.requestId,
      },
    });
  }
});

router.get('/titles/:id/characters', async (req, res) => {
  const local = getDb().prepare('SELECT id FROM titles WHERE id = ?').get(req.params.id);
  if (local) {
    return res.json({ characters: charactersForTitle(req.params.id), source: 'local' });
  }
  const result = await getAnime(req.params.id);
  res.json({ characters: result.title?.characters || [], source: result.source });
});

router.get('/titles/:id/recommendations', async (req, res) => {
  const result = await getRecommendationsFor(req.params.id, Number(req.query.limit) || 12);
  res.json({ items: result.items, mode: result.mode, source: result.source });
});

router.get('/rails', optionalAuth, async (req, res) => {
  const profileId = req.query.profileId || null;
  try {
    if (metadataMode() === 'demo') {
      const data = await railsCached(profileId);
      return res.json({ rails: data, mode: 'DEMO', source: 'local' });
    }
    const live = await liveRails(profileId);
    res.json(live);
  } catch (e) {
    const data = await railsCached(profileId);
    res.json({ rails: data, mode: 'DEMO', source: 'demo-fallback', error: e.message });
  }
});

router.get('/trending', async (req, res) => {
  const result = await getTrending(Number(req.query.limit) || 12);
  res.json(result);
});

router.get('/airing', async (req, res) => {
  const result = await getAiring(Number(req.query.limit) || 12);
  res.json(result);
});

router.get('/seasonal', async (req, res) => {
  const result = await getSeasonal(Number(req.query.limit) || 12);
  res.json(result);
});

router.get('/upcoming', async (req, res) => {
  const result = await getUpcoming(Number(req.query.limit) || 12);
  res.json(result);
});

router.get('/recommendations', optionalAuth, async (req, res) => {
  const { profileId, mood, limit, titleId } = req.query;
  if (titleId) {
    const result = await getRecommendationsFor(titleId, Number(limit) || 12);
    return res.json({ items: result.items, mode: result.mode, source: result.source });
  }
  res.json({
    items: recommendations({ profileId, mood, limit }),
    mood: mood || null,
    mode: 'DEMO',
    source: 'local',
  });
});

router.get('/radar', optionalAuth, async (req, res) => {
  const profileId = req.query.profileId || null;
  const base = radarWeek(profileId);
  if (metadataMode() !== 'demo') {
    try {
      const airing = await getAiring(24);
      if (airing.items?.length) {
        return res.json({ ...base, airing: airing.items, mode: airing.mode, source: airing.source });
      }
    } catch {
      /* */
    }
  }
  res.json({ ...base, mode: 'DEMO', source: 'local' });
});

router.post('/playback-token', requireAuth, (req, res) => {
  const { profileId, episodeId, titleId } = req.body || {};
  if (!profileId || !episodeId) {
    return res.status(400).json({ error: 'profileId and episodeId required' });
  }
  const owned = getDb()
    .prepare('SELECT id FROM profiles WHERE id = ? AND user_id = ?')
    .get(profileId, req.user.sub);
  if (!owned) return res.status(403).json({ error: 'Forbidden' });

  // Local episode only — live metadata has no authorized streams
  const ep = getDb()
    .prepare('SELECT id, title_id AS titleId, intro_start_ms, intro_end_ms FROM episodes WHERE id = ?')
    .get(episodeId);
  if (!ep) {
    return res.status(404).json({
      error: 'PLAYBACK_UNAVAILABLE',
      message: 'No authorized playback for this episode. Metadata does not grant streaming rights.',
    });
  }

  // Rights check when title_rights row exists
  const rights = getDb()
    .prepare('SELECT * FROM title_rights WHERE title_id = ?')
    .get(titleId || ep.titleId);
  if (rights) {
    const now = new Date();
    if (rights.license_end && new Date(rights.license_end) < now) {
      return res.status(403).json({
        error: 'LICENSE_EXPIRED',
        message: 'License window ended — playback unavailable',
      });
    }
  }

  const token = signPlaybackToken({
    userId: req.user.sub,
    profileId,
    episodeId,
    titleId: titleId || ep.titleId,
  });

  res.json({
    token,
    expiresIn: 900,
    episodeId,
    titleId: ep.titleId,
    intro: {
      startMs: ep.intro_start_ms ?? null,
      endMs: ep.intro_end_ms ?? null,
    },
    note: 'Demo token only — no licensed media stream attached',
  });
});

export default router;
