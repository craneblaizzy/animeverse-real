import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.js';
import { requireAuth } from '../middleware/auth.js';
import {
  comparePassword,
  hashPassword,
  hashToken,
  issueRefreshToken,
  newId,
  refreshExpiresAt,
  signAccessToken,
} from '../utils/auth.js';
import { sendPasswordReset, sendEmailVerification } from '../services/email.js';

const router = Router();

const credSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  displayName: z.string().min(1).optional(),
  deviceLabel: z.string().max(80).optional(),
});

function storeRefresh(userId, rawToken, deviceLabel) {
  const id = newId('rt');
  getDb()
    .prepare(
      `INSERT INTO refresh_tokens (id, user_id, token_hash, device_label, expires_at)
       VALUES (?, ?, ?, ?, ?)`
    )
    .run(id, userId, hashToken(rawToken), deviceLabel || null, refreshExpiresAt());
  return id;
}

function profilesFor(userId) {
  return getDb()
    .prepare(
      `SELECT id, name, avatar_color AS avatarColor, is_kids AS isKids, sort_order AS sortOrder
       FROM profiles WHERE user_id = ? ORDER BY sort_order`
    )
    .all(userId);
}

router.post('/register', (req, res) => {
  const parsed = credSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }
  const { email, password, displayName, deviceLabel } = parsed.data;
  const db = getDb();
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) return res.status(409).json({ error: 'Email already registered' });

  const userId = newId('user');
  db.prepare(
    `INSERT INTO users (id, email, password_hash, display_name) VALUES (?, ?, ?, ?)`
  ).run(userId, email, hashPassword(password), displayName || email.split('@')[0]);

  const profileId = newId('profile');
  db.prepare(`INSERT INTO profiles (id, user_id, name, sort_order) VALUES (?, ?, ?, 0)`).run(
    profileId,
    userId,
    displayName || 'Profile 1'
  );
  db.prepare(`INSERT INTO profile_settings (profile_id, settings_json) VALUES (?, ?)`).run(
    profileId,
    JSON.stringify({ cellWarn: true, autoplay: false, reduceMotion: false, accent: 'default' })
  );

  const accessToken = signAccessToken({ sub: userId, email });
  const refreshToken = issueRefreshToken();
  storeRefresh(userId, refreshToken, deviceLabel);

  res.status(201).json({
    token: accessToken,
    refreshToken,
    user: { id: userId, email, displayName: displayName || email.split('@')[0] },
    profileId,
    profiles: profilesFor(userId),
  });
});

router.post('/login', (req, res) => {
  const parsed = credSchema.pick({ email: true, password: true, deviceLabel: true }).safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }
  const { email, password, deviceLabel } = parsed.data;
  const user = getDb().prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !comparePassword(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  if (user.status !== 'active') {
    return res.status(403).json({ error: 'Account not active' });
  }

  const accessToken = signAccessToken({ sub: user.id, email: user.email });
  const refreshToken = issueRefreshToken();
  storeRefresh(user.id, refreshToken, deviceLabel);

  res.json({
    token: accessToken,
    refreshToken,
    user: { id: user.id, email: user.email, displayName: user.display_name },
    profiles: profilesFor(user.id),
  });
});

router.post('/refresh', (req, res) => {
  const refreshToken = req.body?.refreshToken;
  if (!refreshToken) return res.status(400).json({ error: 'refreshToken required' });
  const hash = hashToken(refreshToken);
  const row = getDb()
    .prepare(
      `SELECT * FROM refresh_tokens WHERE token_hash = ? AND revoked = 0`
    )
    .get(hash);
  if (!row) return res.status(401).json({ error: 'Invalid refresh token' });
  if (new Date(row.expires_at) < new Date()) {
    return res.status(401).json({ error: 'Refresh token expired' });
  }

  // Rotate: revoke old, issue new
  getDb().prepare('UPDATE refresh_tokens SET revoked = 1 WHERE id = ?').run(row.id);
  const user = getDb().prepare('SELECT id, email, display_name, status FROM users WHERE id = ?').get(row.user_id);
  if (!user || user.status !== 'active') {
    return res.status(403).json({ error: 'Account not active' });
  }

  const accessToken = signAccessToken({ sub: user.id, email: user.email });
  const newRefresh = issueRefreshToken();
  storeRefresh(user.id, newRefresh, row.device_label);

  res.json({
    token: accessToken,
    refreshToken: newRefresh,
    user: { id: user.id, email: user.email, displayName: user.display_name },
  });
});

router.post('/logout', requireAuth, (req, res) => {
  const refreshToken = req.body?.refreshToken;
  if (refreshToken) {
    getDb()
      .prepare('UPDATE refresh_tokens SET revoked = 1 WHERE token_hash = ? AND user_id = ?')
      .run(hashToken(refreshToken), req.user.sub);
  } else {
    getDb().prepare('UPDATE refresh_tokens SET revoked = 1 WHERE user_id = ?').run(req.user.sub);
  }
  res.json({ ok: true });
});

router.get('/devices', requireAuth, (req, res) => {
  const items = getDb()
    .prepare(
      `SELECT id, device_label AS deviceLabel, expires_at AS expiresAt, revoked, created_at AS createdAt
       FROM refresh_tokens WHERE user_id = ? ORDER BY created_at DESC LIMIT 20`
    )
    .all(req.user.sub);
  res.json({ items });
});

router.delete('/devices/:id', requireAuth, (req, res) => {
  getDb()
    .prepare('UPDATE refresh_tokens SET revoked = 1 WHERE id = ? AND user_id = ?')
    .run(req.params.id, req.user.sub);
  res.json({ ok: true });
});

router.get('/me', requireAuth, (req, res) => {
  const user = getDb()
    .prepare('SELECT id, email, display_name AS displayName, status FROM users WHERE id = ?')
    .get(req.user.sub);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user, profiles: profilesFor(user.id) });
});



/** Request password reset — returns token in dev only (no email send) */
router.post('/password-reset/request', async (req, res) => {
  const email = req.body?.email;
  if (!email) return res.status(400).json({ error: 'email required' });
  const user = getDb().prepare('SELECT id, email FROM users WHERE email = ?').get(email);
  // Always 200 to avoid email enumeration
  if (!user) return res.json({ ok: true, message: 'If the account exists, a reset was issued' });
  const raw = issueRefreshToken();
  const id = newId('pwreset');
  const expires = new Date(Date.now() + 60 * 60 * 1000).toISOString();
  getDb()
    .prepare(
      `INSERT INTO password_resets (id, user_id, token_hash, expires_at) VALUES (?, ?, ?, ?)`
    )
    .run(id, user.id, hashToken(raw), expires);
  const payload = { ok: true, message: 'If the account exists, a reset was issued' };
  try { await sendPasswordReset(email, raw); } catch (e) { console.warn('email', e.message); }
  if (process.env.NODE_ENV !== 'production') {
    payload.devToken = raw;
    payload.devNote = 'Dev only — use POST /v1/auth/password-reset/confirm';
  }
  res.json(payload);
});

router.post('/password-reset/confirm', (req, res) => {
  const { token, password } = req.body || {};
  if (!token || !password || String(password).length < 6) {
    return res.status(400).json({ error: 'token and password (min 6) required' });
  }
  const row = getDb()
    .prepare(
      `SELECT * FROM password_resets WHERE token_hash = ? AND used = 0`
    )
    .get(hashToken(token));
  if (!row || new Date(row.expires_at) < new Date()) {
    return res.status(400).json({ error: 'Invalid or expired token' });
  }
  getDb()
    .prepare(`UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?`)
    .run(hashPassword(password), row.user_id);
  getDb().prepare(`UPDATE password_resets SET used = 1 WHERE id = ?`).run(row.id);
  getDb().prepare(`UPDATE refresh_tokens SET revoked = 1 WHERE user_id = ?`).run(row.user_id);
  res.json({ ok: true });
});

/** GDPR-style data export for authenticated user */
router.get('/gdpr/export', requireAuth, (req, res) => {
  const db = getDb();
  const user = db
    .prepare('SELECT id, email, display_name AS displayName, locale, created_at AS createdAt FROM users WHERE id = ?')
    .get(req.user.sub);
  const profiles = db
    .prepare('SELECT id, name, is_kids AS isKids, created_at AS createdAt FROM profiles WHERE user_id = ?')
    .all(req.user.sub);
  const profileIds = profiles.map((p) => p.id);
  let watchlist = [];
  let progress = [];
  if (profileIds.length) {
    const placeholders = profileIds.map(() => '?').join(',');
    watchlist = db
      .prepare(
        `SELECT profile_id AS profileId, title_id AS titleId, created_at AS addedAt FROM watchlist WHERE profile_id IN (${placeholders})`
      )
      .all(...profileIds);
    progress = db
      .prepare(
        `SELECT profile_id AS profileId, episode_id AS episodeId, position_ms AS positionMs, completed, updated_at AS updatedAt
         FROM watch_progress WHERE profile_id IN (${placeholders})`
      )
      .all(...profileIds);
  }
  res.json({
    exportedAt: new Date().toISOString(),
    user,
    profiles,
    watchlist,
    progress,
  });
});

/** GDPR delete account (soft → deleted status + revoke tokens) */
router.post('/gdpr/delete', requireAuth, (req, res) => {
  const confirm = req.body?.confirm;
  if (confirm !== 'DELETE') {
    return res.status(400).json({ error: 'Send { "confirm": "DELETE" }' });
  }
  const db = getDb();
  db.prepare(`UPDATE users SET status = 'deleted', updated_at = datetime('now') WHERE id = ?`).run(req.user.sub);
  db.prepare(`UPDATE refresh_tokens SET revoked = 1 WHERE user_id = ?`).run(req.user.sub);
  res.json({ ok: true, message: 'Account marked deleted' });
});



/** Request email verification token (dev returns token) */
router.post('/email-verify/request', requireAuth, async (req, res) => {
  const raw = issueRefreshToken();
  const id = newId('everify');
  const expires = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
  getDb()
    .prepare(
      `INSERT INTO email_verifications (id, user_id, token_hash, expires_at) VALUES (?, ?, ?, ?)`
    )
    .run(id, req.user.sub, hashToken(raw), expires);
  const payload = { ok: true, message: 'Verification issued' };
  if (process.env.NODE_ENV !== 'production') {
    payload.devToken = raw;
  }
  res.json(payload);
});

router.post('/email-verify/confirm', (req, res) => {
  const token = req.body?.token;
  if (!token) return res.status(400).json({ error: 'token required' });
  const row = getDb()
    .prepare(`SELECT * FROM email_verifications WHERE token_hash = ? AND used = 0`)
    .get(hashToken(token));
  if (!row || new Date(row.expires_at) < new Date()) {
    return res.status(400).json({ error: 'Invalid or expired token' });
  }
  getDb().prepare(`UPDATE email_verifications SET used = 1 WHERE id = ?`).run(row.id);
  getDb()
    .prepare(
      `INSERT INTO user_flags (user_id, email_verified, updated_at) VALUES (?, 1, datetime('now'))
       ON CONFLICT(user_id) DO UPDATE SET email_verified = 1, updated_at = datetime('now')`
    )
    .run(row.user_id);
  res.json({ ok: true, emailVerified: true });
});

export default router;


