import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.js';
import { requireAuth } from '../middleware/auth.js';
import {
  applyPackagerEvent,
  ensureEpisodeAsset,
  mintCdnUrl,
  verifyCdnSig,
  verifyPackagerSignature,
} from '../services/media.js';

const router = Router();

/** Mint signed CDN URL for an episode (auth required) */
router.post('/cdn/mint', requireAuth, (req, res) => {
  const schema = z.object({
    episodeId: z.string(),
    quality: z.string().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }
  const asset = ensureEpisodeAsset(parsed.data.episodeId, parsed.data.quality || '720p');
  if (!asset) return res.status(404).json({ error: 'Episode not found' });
  res.json({ asset });
});

/** Debug: check CDN signature validity */
router.get('/cdn/verify', (req, res) => {
  const path = req.query.path;
  const exp = req.query.exp;
  const sig = req.query.sig;
  if (!path) return res.status(400).json({ error: 'path required' });
  res.json({ path, exp, sig, valid: verifyCdnSig(String(path), exp, sig) });
});


/**
 * Packager webhook — external packager reports grant progress.
 * Header: X-Packager-Signature: sha256=<hmac>
 * Body: { grantId, eventType, progress?, error?, assetPath? }
 */
router.post('/webhooks/packager', (req, res) => {
  const sig = req.headers['x-packager-signature'] || req.headers['x-signature'];
  const skipVerify = process.env.PACKAGER_SKIP_VERIFY === '1';

  if (!skipVerify && !verifyPackagerSignature(req.body, sig)) {
    return res.status(401).json({ error: 'Invalid packager signature' });
  }

  const schema = z.object({
    grantId: z.string(),
    eventType: z.enum(['queued', 'progress', 'ready', 'failed', 'expired']),
    progress: z.number().min(0).max(1).optional(),
    error: z.string().optional(),
    assetPath: z.string().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }

  const result = applyPackagerEvent(parsed.data);
  if (!result.ok) return res.status(404).json(result);
  res.json(result);
});

/** List packager events for a grant (owner only) */
router.get('/profiles/:profileId/offline-grants/:grantId/events', requireAuth, (req, res) => {
  const owned = getDb()
    .prepare('SELECT id FROM profiles WHERE id = ? AND user_id = ?')
    .get(req.params.profileId, req.user.sub);
  if (!owned) return res.status(403).json({ error: 'Forbidden' });

  const grant = getDb()
    .prepare('SELECT id FROM offline_grants WHERE id = ? AND profile_id = ?')
    .get(req.params.grantId, req.params.profileId);
  if (!grant) return res.status(404).json({ error: 'Grant not found' });

  const items = getDb()
    .prepare(
      `SELECT id, event_type AS eventType, payload_json AS payloadJson, created_at AS createdAt
       FROM packager_events WHERE grant_id = ? ORDER BY created_at DESC LIMIT 50`
    )
    .all(req.params.grantId)
    .map((r) => {
      let payload = {};
      try {
        payload = JSON.parse(r.payloadJson || '{}');
      } catch {
        /* */
      }
      return { id: r.id, eventType: r.eventType, payload, createdAt: r.createdAt };
    });

  res.json({ items });
});

/** Poster / static path mint (no auth — public catalog art would be public CDN) */
router.get('/cdn/poster/:titleId', (req, res) => {
  const title = getDb().prepare('SELECT id FROM titles WHERE id = ?').get(req.params.titleId);
  if (!title) return res.status(404).json({ error: 'Title not found' });
  const path = `/posters/${req.params.titleId}.webp`;
  res.json(mintCdnUrl({ path, expiresInSec: 86400 }));
});

export default router;
