import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.js';
import { requireAuth } from '../middleware/auth.js';
import { newId } from '../utils/auth.js';
import { randomBytes } from 'crypto';

const router = Router();
router.use(requireAuth);

function assertProfileOwned(userId, profileId) {
  return getDb()
    .prepare('SELECT id FROM profiles WHERE id = ? AND user_id = ?')
    .get(profileId, userId);
}

function roomCode() {
  return randomBytes(3).toString('hex').toUpperCase();
}

function mapRoom(row) {
  if (!row) return null;
  let meta = {};
  try {
    meta = JSON.parse(row.meta_json || '{}');
  } catch {
    meta = {};
  }
  return {
    id: row.id,
    hostProfileId: row.host_profile_id,
    titleId: row.title_id,
    episodeId: row.episode_id,
    code: row.code,
    status: row.status,
    maxGuests: row.max_guests,
    meta,
    createdAt: row.created_at,
    closedAt: row.closed_at,
  };
}

router.post('/rooms', (req, res) => {
  const schema = z.object({
    profileId: z.string(),
    titleId: z.string(),
    episodeId: z.string().optional(),
    maxGuests: z.number().int().min(2).max(20).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }
  const { profileId, titleId, episodeId, maxGuests } = parsed.data;
  if (!assertProfileOwned(req.user.sub, profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const title = getDb().prepare('SELECT id FROM titles WHERE id = ?').get(titleId);
  if (!title) return res.status(404).json({ error: 'Title not found' });

  const id = newId('room');
  let code = roomCode();
  // ensure unique
  for (let i = 0; i < 5; i++) {
    const exists = getDb().prepare('SELECT id FROM watch_rooms WHERE code = ?').get(code);
    if (!exists) break;
    code = roomCode();
  }

  getDb()
    .prepare(
      `INSERT INTO watch_rooms (id, host_profile_id, title_id, episode_id, code, status, max_guests)
       VALUES (?, ?, ?, ?, ?, 'open', ?)`
    )
    .run(id, profileId, titleId, episodeId || null, code, maxGuests || 8);

  getDb()
    .prepare(
      `INSERT INTO watch_room_members (room_id, profile_id, role) VALUES (?, ?, 'host')`
    )
    .run(id, profileId);

  const room = getDb().prepare('SELECT * FROM watch_rooms WHERE id = ?').get(id);
  res.status(201).json({ room: mapRoom(room) });
});

router.get('/rooms/:code', (req, res) => {
  const row = getDb()
    .prepare(`SELECT * FROM watch_rooms WHERE code = ? OR id = ?`)
    .get(req.params.code.toUpperCase(), req.params.code);
  if (!row) return res.status(404).json({ error: 'Room not found' });
  const members = getDb()
    .prepare(
      `SELECT m.profile_id AS profileId, p.name, m.role, m.joined_at AS joinedAt
       FROM watch_room_members m JOIN profiles p ON p.id = m.profile_id
       WHERE m.room_id = ?`
    )
    .all(row.id);
  res.json({ room: mapRoom(row), members });
});

router.post('/rooms/:code/join', (req, res) => {
  const profileId = req.body?.profileId;
  if (!profileId) return res.status(400).json({ error: 'profileId required' });
  if (!assertProfileOwned(req.user.sub, profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const row = getDb()
    .prepare(`SELECT * FROM watch_rooms WHERE code = ? OR id = ?`)
    .get(req.params.code.toUpperCase(), req.params.code);
  if (!row) return res.status(404).json({ error: 'Room not found' });
  if (row.status === 'closed') return res.status(410).json({ error: 'Room closed' });

  const count = getDb()
    .prepare('SELECT COUNT(*) AS c FROM watch_room_members WHERE room_id = ?')
    .get(row.id)?.c;
  if (count >= row.max_guests) return res.status(409).json({ error: 'Room full' });

  getDb()
    .prepare(
      `INSERT OR IGNORE INTO watch_room_members (room_id, profile_id, role) VALUES (?, ?, 'guest')`
    )
    .run(row.id, profileId);

  if (row.status === 'open') {
    getDb().prepare(`UPDATE watch_rooms SET status = 'live' WHERE id = ?`).run(row.id);
  }

  res.json({ ok: true, roomId: row.id, code: row.code });
});

router.post('/rooms/:code/signal', (req, res) => {
  /** Signaling envelope: { type, payload } stored in meta for demo poll clients */
  const row = getDb()
    .prepare(`SELECT * FROM watch_rooms WHERE code = ? OR id = ?`)
    .get(req.params.code.toUpperCase(), req.params.code);
  if (!row) return res.status(404).json({ error: 'Room not found' });

  let meta = {};
  try {
    meta = JSON.parse(row.meta_json || '{}');
  } catch {
    meta = {};
  }
  const signals = Array.isArray(meta.signals) ? meta.signals : [];
  signals.push({
    at: new Date().toISOString(),
    from: req.user.sub,
    type: req.body?.type || 'ping',
    payload: req.body?.payload ?? null,
  });
  // keep last 30
  meta.signals = signals.slice(-30);
  getDb()
    .prepare(`UPDATE watch_rooms SET meta_json = ? WHERE id = ?`)
    .run(JSON.stringify(meta), row.id);

  res.json({ ok: true, signalCount: meta.signals.length });
});

router.post('/rooms/:code/close', (req, res) => {
  const row = getDb()
    .prepare(`SELECT * FROM watch_rooms WHERE code = ? OR id = ?`)
    .get(req.params.code.toUpperCase(), req.params.code);
  if (!row) return res.status(404).json({ error: 'Room not found' });

  const host = getDb()
    .prepare('SELECT user_id FROM profiles WHERE id = ?')
    .get(row.host_profile_id);
  if (host?.user_id !== req.user.sub) {
    return res.status(403).json({ error: 'Only host can close' });
  }
  getDb()
    .prepare(`UPDATE watch_rooms SET status = 'closed', closed_at = datetime('now') WHERE id = ?`)
    .run(row.id);
  res.json({ ok: true });
});

export default router;
