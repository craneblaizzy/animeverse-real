import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.js';
import { requireAuth } from '../middleware/auth.js';
import { newId, hashPassword, comparePassword } from '../utils/auth.js';
import { enqueuePackagerJob } from '../services/media.js';

const router = Router();
router.use(requireAuth);

function assertProfileOwned(userId, profileId) {
  return getDb()
    .prepare('SELECT id FROM profiles WHERE id = ? AND user_id = ?')
    .get(profileId, userId);
}

router.get('/profiles', (req, res) => {
  const profiles = getDb()
    .prepare(
      `SELECT id, name, avatar_color AS avatarColor, is_kids AS isKids, sort_order AS sortOrder
       FROM profiles WHERE user_id = ? ORDER BY sort_order`
    )
    .all(req.user.sub);
  res.json({ profiles });
});

router.get('/profiles/:profileId/watchlist', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const items = getDb()
    .prepare(
      `SELECT t.id, t.title, t.year, t.rating, t.poster_gradient AS posterGradient, w.created_at AS addedAt
       FROM watchlist w JOIN titles t ON t.id = w.title_id
       WHERE w.profile_id = ? ORDER BY w.created_at DESC`
    )
    .all(req.params.profileId);
  res.json({ items });
});

router.post('/profiles/:profileId/watchlist', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const titleId = req.body?.titleId;
  if (!titleId) return res.status(400).json({ error: 'titleId required' });
  const title = getDb().prepare('SELECT id FROM titles WHERE id = ?').get(titleId);
  if (!title) return res.status(404).json({ error: 'Title not found' });
  getDb()
    .prepare(
      `INSERT OR IGNORE INTO watchlist (profile_id, title_id) VALUES (?, ?)`
    )
    .run(req.params.profileId, titleId);
  res.status(201).json({ ok: true, titleId });
});

router.delete('/profiles/:profileId/watchlist/:titleId', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  getDb()
    .prepare('DELETE FROM watchlist WHERE profile_id = ? AND title_id = ?')
    .run(req.params.profileId, req.params.titleId);
  res.json({ ok: true });
});

router.put('/progress', (req, res) => {
  const schema = z.object({
    profileId: z.string(),
    episodeId: z.string(),
    positionMs: z.number().int().min(0),
    durationMs: z.number().int().positive().optional(),
    completed: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }
  const { profileId, episodeId, positionMs, durationMs, completed } = parsed.data;
  if (!assertProfileOwned(req.user.sub, profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const ep = getDb().prepare('SELECT id FROM episodes WHERE id = ?').get(episodeId);
  if (!ep) return res.status(404).json({ error: 'Episode not found' });

  getDb()
    .prepare(
      `INSERT INTO watch_progress (profile_id, episode_id, position_ms, duration_ms, completed, updated_at)
       VALUES (?, ?, ?, ?, ?, datetime('now'))
       ON CONFLICT(profile_id, episode_id) DO UPDATE SET
         position_ms = excluded.position_ms,
         duration_ms = COALESCE(excluded.duration_ms, watch_progress.duration_ms),
         completed = excluded.completed,
         updated_at = datetime('now')`
    )
    .run(profileId, episodeId, positionMs, durationMs ?? null, completed ? 1 : 0);

  res.json({ ok: true });
});

router.get('/profiles/:profileId/progress', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const items = getDb()
    .prepare(
      `SELECT wp.episode_id AS episodeId, e.title_id AS titleId, e.episode_number AS episodeNumber,
              wp.position_ms AS positionMs, wp.duration_ms AS durationMs, wp.completed, wp.updated_at AS updatedAt
       FROM watch_progress wp
       JOIN episodes e ON e.id = wp.episode_id
       WHERE wp.profile_id = ?
       ORDER BY wp.updated_at DESC`
    )
    .all(req.params.profileId);
  res.json({ items });
});

router.post('/profiles/:profileId/hidden', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const titleId = req.body?.titleId;
  if (!titleId) return res.status(400).json({ error: 'titleId required' });
  getDb()
    .prepare(`INSERT OR IGNORE INTO hidden_titles (profile_id, title_id) VALUES (?, ?)`)
    .run(req.params.profileId, titleId);
  res.status(201).json({ ok: true });
});

router.get('/notifications', (req, res) => {
  const items = getDb()
    .prepare(
      `SELECT id, title, body, unread, created_at AS createdAt FROM notifications
       WHERE user_id = ? ORDER BY created_at DESC LIMIT 50`
    )
    .all(req.user.sub);
  res.json({ items });
});

router.post('/notifications/read-all', (req, res) => {
  getDb().prepare('UPDATE notifications SET unread = 0 WHERE user_id = ?').run(req.user.sub);
  res.json({ ok: true });
});

router.post('/profiles/:profileId/offline-grants', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const { titleId, pack = 'episode', quality = '720p', episodes = [] } = req.body || {};
  if (!titleId) return res.status(400).json({ error: 'titleId required' });
  const title = getDb().prepare('SELECT id, title, episodes FROM titles WHERE id = ?').get(titleId);
  if (!title) return res.status(404).json({ error: 'Title not found' });

  const id = newId('grant');
  const expires = new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString();
  const sizeMb =
    pack === 'season' ? 400 + (title.episodes || 12) * 35 : 180 + Math.min(title.episodes || 12, 3) * 8;

  getDb()
    .prepare(
      `INSERT INTO offline_grants (id, profile_id, title_id, pack, quality, episodes_json, status, progress, size_mb, expires_at)
       VALUES (?, ?, ?, ?, ?, ?, 'queued', 0, ?, ?)`
    )
    .run(
      id,
      req.params.profileId,
      titleId,
      pack,
      quality,
      JSON.stringify(episodes),
      sizeMb,
      expires
    );

  try { enqueuePackagerJob(id); } catch (e) { console.warn('packager enqueue', e.message); }

  res.status(201).json({
    grant: {
      id,
      titleId,
      title: title.title,
      pack,
      quality,
      status: 'queued',
      progress: 0,
      sizeMb,
      expiresAt: expires,
      note: 'Metadata grant queued for packager webhook pipeline',
    },
  });
});

router.get('/profiles/:profileId/offline-grants', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const items = getDb()
    .prepare(
      `SELECT g.id, g.title_id AS titleId, t.title, g.pack, g.quality, g.status, g.progress,
              g.size_mb AS sizeMb, g.expires_at AS expiresAt, g.episodes_json AS episodesJson, g.created_at AS createdAt
       FROM offline_grants g JOIN titles t ON t.id = g.title_id
       WHERE g.profile_id = ? ORDER BY g.created_at DESC`
    )
    .all(req.params.profileId);
  res.json({ items });
});


router.post('/profiles', (req, res) => {
  const schema = z.object({
    name: z.string().min(1).max(40),
    avatarColor: z.string().optional(),
    isKids: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }
  const { name, avatarColor, isKids } = parsed.data;
  const id = newId('profile');
  const maxOrder = getDb()
    .prepare('SELECT COALESCE(MAX(sort_order), -1) AS m FROM profiles WHERE user_id = ?')
    .get(req.user.sub);
  getDb()
    .prepare(
      `INSERT INTO profiles (id, user_id, name, avatar_color, is_kids, sort_order) VALUES (?, ?, ?, ?, ?, ?)`
    )
    .run(
      id,
      req.user.sub,
      name,
      avatarColor || 'linear-gradient(135deg,#6E7CF6,#a78bfa)',
      isKids ? 1 : 0,
      (maxOrder?.m ?? -1) + 1
    );
  res.status(201).json({
    id,
    name,
    avatarColor: avatarColor || 'linear-gradient(135deg,#6E7CF6,#a78bfa)',
    isKids: !!isKids,
  });
});

router.patch('/profiles/:profileId', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const schema = z.object({
    name: z.string().min(1).max(40).optional(),
    avatarColor: z.string().optional(),
    sortOrder: z.number().int().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'ValidationError', details: parsed.error.flatten() });
  }
  const d = parsed.data;
  if (d.name !== undefined) {
    getDb().prepare('UPDATE profiles SET name = ? WHERE id = ?').run(d.name, req.params.profileId);
  }
  if (d.avatarColor !== undefined) {
    getDb().prepare('UPDATE profiles SET avatar_color = ? WHERE id = ?').run(d.avatarColor, req.params.profileId);
  }
  if (d.sortOrder !== undefined) {
    getDb().prepare('UPDATE profiles SET sort_order = ? WHERE id = ?').run(d.sortOrder, req.params.profileId);
  }
  res.json({ ok: true });
});

router.delete('/profiles/:profileId', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const count = getDb()
    .prepare('SELECT COUNT(*) AS c FROM profiles WHERE user_id = ?')
    .get(req.user.sub);
  if ((count?.c || 0) <= 1) {
    return res.status(400).json({ error: 'Cannot delete last profile' });
  }
  getDb().prepare('DELETE FROM profiles WHERE id = ?').run(req.params.profileId);
  res.json({ ok: true });
});

router.post('/profiles/:profileId/pin', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const pin = String(req.body?.pin ?? '');
  if (!/^\d{4,6}$/.test(pin)) {
    return res.status(400).json({ error: 'PIN must be 4–6 digits' });
  }
  getDb()
    .prepare('UPDATE profiles SET pin_hash = ? WHERE id = ?')
    .run(hashPassword(pin), req.params.profileId);
  res.json({ ok: true, hasPin: true });
});

router.post('/profiles/:profileId/pin/verify', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const pin = String(req.body?.pin ?? '');
  const row = getDb()
    .prepare('SELECT pin_hash AS pinHash FROM profiles WHERE id = ?')
    .get(req.params.profileId);
  if (!row?.pinHash) {
    return res.json({ ok: true, required: false });
  }
  if (!comparePassword(pin, row.pinHash)) {
    return res.status(401).json({ error: 'Invalid PIN' });
  }
  res.json({ ok: true, required: true });
});

router.get('/profiles/:profileId/settings', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const row = getDb()
    .prepare('SELECT settings_json AS settingsJson FROM profile_settings WHERE profile_id = ?')
    .get(req.params.profileId);
  let settings = {};
  try {
    settings = JSON.parse(row?.settingsJson || '{}');
  } catch {
    settings = {};
  }
  res.json({ settings });
});

router.put('/profiles/:profileId/settings', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const settings = req.body?.settings ?? req.body ?? {};
  getDb()
    .prepare(
      `INSERT INTO profile_settings (profile_id, settings_json, updated_at)
       VALUES (?, ?, datetime('now'))
       ON CONFLICT(profile_id) DO UPDATE SET
         settings_json = excluded.settings_json,
         updated_at = datetime('now')`
    )
    .run(req.params.profileId, JSON.stringify(settings));
  res.json({ ok: true, settings });
});




router.patch('/profiles/:profileId/offline-grants/:grantId', (req, res) => {
  if (!assertProfileOwned(req.user.sub, req.params.profileId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const status = req.body?.status;
  const allowed = ['queued', 'downloading', 'ready', 'expired', 'cancelled', 'failed'];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: 'Invalid status', allowed });
  }
  const g = getDb()
    .prepare('SELECT id FROM offline_grants WHERE id = ? AND profile_id = ?')
    .get(req.params.grantId, req.params.profileId);
  if (!g) return res.status(404).json({ error: 'Grant not found' });
  const progress = req.body?.progress;
  if (progress != null) {
    getDb()
      .prepare('UPDATE offline_grants SET status = ?, progress = ? WHERE id = ?')
      .run(status, Number(progress), req.params.grantId);
  } else {
    getDb()
      .prepare('UPDATE offline_grants SET status = ? WHERE id = ?')
      .run(status, req.params.grantId);
  }
  res.json({ ok: true, id: req.params.grantId, status });
});

export default router;


