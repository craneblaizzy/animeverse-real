import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.js';
import { requireAuth } from '../middleware/auth.js';
import {
  hashPassword,
  newId,
  signAccessToken,
  issueRefreshToken,
  hashToken,
  refreshExpiresAt,
} from '../utils/auth.js';
import { inc } from '../services/metrics.js';

const router = Router();

/**
 * OAuth stub providers (Google / Apple).
 * Production: validate id_token with provider JWKS.
 * Dev: POST { provider, idToken, email, name } simulates verified token payload.
 */

const providers = {
  google: {
    clientId: process.env.GOOGLE_CLIENT_ID || 'google-client-id-dev',
    authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
  },
  apple: {
    clientId: process.env.APPLE_CLIENT_ID || 'apple-client-id-dev',
    authUrl: 'https://appleid.apple.com/auth/authorize',
  },
};

router.get('/oauth/:provider/start', (req, res) => {
  const provider = req.params.provider;
  const cfg = providers[provider];
  if (!cfg) return res.status(400).json({ error: 'Unsupported provider' });
  const redirectUri =
    req.query.redirect_uri ||
    process.env.OAUTH_REDIRECT_URI ||
    'http://localhost:8787/v1/auth/oauth/callback';
  const state = newId('oauth');
  // In production store state in redis/session
  res.json({
    provider,
    authorizeUrl: `${cfg.authUrl}?client_id=${cfg.clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=email%20profile&state=${state}`,
    state,
    note: 'Demo authorize URL — complete flow via POST /v1/auth/oauth/:provider/callback with simulated profile',
  });
});

router.post('/oauth/:provider/callback', (req, res) => {
  const provider = req.params.provider;
  if (!providers[provider]) return res.status(400).json({ error: 'Unsupported provider' });

  const schema = z.object({
    idToken: z.string().optional(),
    code: z.string().optional(),
    email: z.string().email(),
    name: z.string().optional(),
    providerUserId: z.string().min(1),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({
      error: 'ValidationError',
      message: 'Provide email + providerUserId (and idToken in production)',
      details: parsed.error.flatten(),
    });
  }

  const { email, name, providerUserId } = parsed.data;
  const db = getDb();

  // Existing OAuth link?
  let link = db
    .prepare('SELECT * FROM oauth_accounts WHERE provider = ? AND provider_user_id = ?')
    .get(provider, providerUserId);

  let userId;
  if (link) {
    userId = link.user_id;
  } else {
    // Match by email or create
    let user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!user) {
      userId = newId('user');
      const randomPass = hashPassword(newId('oauth'));
      db.prepare(
        `INSERT INTO users (id, email, password_hash, display_name) VALUES (?, ?, ?, ?)`
      ).run(userId, email, randomPass, name || email.split('@')[0]);
      const profileId = newId('profile');
      db.prepare(`INSERT INTO profiles (id, user_id, name, sort_order) VALUES (?, ?, ?, 0)`).run(
        profileId,
        userId,
        name || 'Profile 1'
      );
    } else {
      userId = user.id;
    }
    const oid = newId('oauth');
    db.prepare(
      `INSERT INTO oauth_accounts (id, user_id, provider, provider_user_id, email)
       VALUES (?, ?, ?, ?, ?)`
    ).run(oid, userId, provider, providerUserId, email);
  }

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  if (!user || user.status !== 'active') {
    return res.status(403).json({ error: 'Account not active' });
  }

  const accessToken = signAccessToken({ sub: user.id, email: user.email });
  const refreshToken = issueRefreshToken();
  db.prepare(
    `INSERT INTO refresh_tokens (id, user_id, token_hash, device_label, expires_at)
     VALUES (?, ?, ?, ?, ?)`
  ).run(newId('rt'), user.id, hashToken(refreshToken), `oauth:${provider}`, refreshExpiresAt());

  const profiles = db
    .prepare(
      `SELECT id, name, avatar_color AS avatarColor, is_kids AS isKids FROM profiles WHERE user_id = ?`
    )
    .all(user.id);

  inc('oauth_logins_total', { provider });
  res.json({
    token: accessToken,
    refreshToken,
    user: { id: user.id, email: user.email, displayName: user.display_name },
    profiles,
    provider,
  });
});

router.get('/oauth/links', requireAuth, (req, res) => {
  const items = getDb()
    .prepare(
      `SELECT id, provider, provider_user_id AS providerUserId, email, created_at AS createdAt
       FROM oauth_accounts WHERE user_id = ?`
    )
    .all(req.user.sub);
  res.json({ items });
});

router.delete('/oauth/links/:id', requireAuth, (req, res) => {
  getDb()
    .prepare('DELETE FROM oauth_accounts WHERE id = ? AND user_id = ?')
    .run(req.params.id, req.user.sub);
  res.json({ ok: true });
});

export default router;
