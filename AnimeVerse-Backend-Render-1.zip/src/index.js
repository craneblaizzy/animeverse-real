import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { getDbPath } from './db/connection.js';
import { requestId } from './middleware/requestId.js';
import { rateLimit } from './middleware/rateLimit.js';
import { metricsMiddleware, metricsSnapshot } from './services/metrics.js';
import { initCache, cacheMode } from './services/cache.js';
import catalogRoutes from './routes/catalog.js';
import authRoutes from './routes/auth.js';
import userRoutes from './routes/user.js';
import communityRoutes from './routes/community.js';
import adminRoutes from './routes/admin.js';
import roomsRoutes from './routes/rooms.js';
import socialRoutes from './routes/social.js';
import mediaRoutes from './routes/media.js';
import oauthRoutes from './routes/oauth.js';
import { healthDeep } from './services/jobs.js';
import { startScheduler } from './services/scheduler.js';
import { getOutbox } from './services/email.js';

const app = express();
const PORT = process.env.PORT || 8787;

app.set('trust proxy', 1);
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(requestId);
app.use(rateLimit);
app.use(metricsMiddleware);

app.get('/', (_req, res) => {
  res.json({
    name: 'AnimeVerse API',
    version: '1.1.0',
    progress: '100%+live-metadata',
    openapi: '/v1/openapi.json',
    cache: cacheMode(),
    docs: {
      health: 'GET /v1/health · /v1/health/deep · /v1/metrics',
      auth: 'login|register|refresh|oauth|password-reset|email-verify|gdpr',
      catalog: 'titles|search|rails(cached)|recommendations|radar|timeline',
      media: 'cdn/mint|webhooks/packager|playback-token',
      social: 'feed|follow|rooms|reviews',
      admin: '/v1/admin/* including title rights',
      providers: 'GET /v1/meta/status · /v1/trending · /v1/airing · /v1/seasonal',
    },
    database: getDbPath(),
  });
});

app.get('/v1/health/deep', (_req, res) => {
  try {
    res.json({ ...healthDeep(), cache: cacheMode() });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.get('/v1/metrics', (_req, res) => {
  res.json(metricsSnapshot());
});

app.get('/v1/dev/outbox', (_req, res) => {
  if (process.env.NODE_ENV === 'production') {
    return res.status(404).json({ error: 'Not found' });
  }
  res.json({ emails: getOutbox() });
});

app.get('/v1/openapi.json', (_req, res) => {
  res.json({
    openapi: '3.0.3',
    info: { title: 'AnimeVerse API', version: '1.1.0' },
    servers: [{ url: 'http://localhost:8787/v1' }],
    paths: {
      '/health': { get: { summary: 'Liveness' } },
      '/health/deep': { get: { summary: 'DB counts + jobs' } },
      '/metrics': { get: { summary: 'In-process metrics snapshot' } },
      '/auth/login': { post: { summary: 'Login' } },
      '/auth/oauth/{provider}/callback': { post: { summary: 'OAuth login stub' } },
      '/titles': { get: { summary: 'List titles' } },
      '/search': { get: { summary: 'Search + facets' } },
      '/rails': { get: { summary: 'Home rails (cached)' } },
      '/cdn/mint': { post: { summary: 'Signed CDN URL' } },
      '/webhooks/packager': { post: { summary: 'Packager webhook' } },
      '/admin/stats': { get: { summary: 'Admin stats' } },
    },
  });
});

app.use('/v1', catalogRoutes);
app.use('/v1/auth', authRoutes);
app.use('/v1/auth', oauthRoutes);
app.use('/v1', userRoutes);
app.use('/v1', communityRoutes);
app.use('/v1', roomsRoutes);
app.use('/v1', socialRoutes);
app.use('/v1', mediaRoutes);
app.use('/v1/admin', adminRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'InternalServerError', message: err.message });
});

await initCache();

app.listen(PORT, () => {
  console.log(`AnimeVerse API http://localhost:${PORT}`);
  console.log(`SQLite: ${getDbPath()} · cache: ${cacheMode()}`);
  startScheduler();
});
