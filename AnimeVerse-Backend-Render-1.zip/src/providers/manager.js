/**
 * Provider manager: cache → Jikan → AniList → TMDB → local DB.
 * Never mixes demo catalog IDs with live provider results in the same list
 * unless mode is explicit.
 */

import { jikanProvider } from './jikan.js';
import { anilistProvider } from './anilist.js';
import { tmdbProvider } from './tmdb.js';
import { dedupeByExternalIds, internalIdFromMal } from './normalize.js';
import { getDb } from '../db/connection.js';
import * as localCatalog from '../services/catalog.js';
import { cacheGet, cacheSet } from '../services/cache.js';

function safeLocalTitle(id) {
  try {
    return safeLocalTitle(id);
  } catch {
    return null;
  }
}

function safeListTitles(opts) {
  try {
    return safeListTitles(opts);
  } catch {
    return [];
  }
}

/** demo = local mock only; live = providers + local; hybrid = live rails with local fallback */
export function metadataMode() {
  return process.env.METADATA_MODE || 'live';
}

function providers() {
  // Priority: Jikan → AniList → TMDB
  return [jikanProvider, anilistProvider, tmdbProvider].filter((p) => p.enabled);
}

async function tryProviders(method, ...args) {
  const errors = [];
  for (const p of providers()) {
    if (typeof p[method] !== 'function') continue;
    try {
      const result = await p[method](...args);
      if (result != null && !(Array.isArray(result) && result.length === 0)) {
        return { result, provider: p.name, errors };
      }
    } catch (e) {
      errors.push({ provider: p.name, code: e.code || 'ERROR', message: e.message });
    }
  }
  return { result: null, provider: null, errors };
}

export async function searchAnime(q, opts = {}) {
  const mode = metadataMode();
  if (mode === 'demo' || !q?.trim()) {
    return {
      items: safeListTitles({ q, limit: opts.limit || 24 }),
      source: 'demo',
      mode: 'DEMO',
    };
  }

  const cacheKey = `mgr:search:${q.trim().toLowerCase()}:${opts.limit || 24}`;
  const cached = await cacheGet(cacheKey);
  if (cached) return { ...cached, cached: true };

  const { result, provider, errors } = await tryProviders('searchAnime', q, opts);
  let items = Array.isArray(result) ? result : [];

  // Optional TMDB supplement for sparse results
  if (items.length < 5 && tmdbProvider.enabled) {
    try {
      const extra = await tmdbProvider.searchAnime(q, opts);
      items = dedupeByExternalIds([...items, ...extra]);
    } catch {
      /* ignore */
    }
  }

  if (!items.length) {
    const local = safeListTitles({ q, limit: opts.limit || 24 });
    return {
      items: local,
      source: 'demo-fallback',
      mode: 'DEMO',
      upstreamErrors: errors,
    };
  }

  const payload = {
    items,
    source: provider || 'mixed',
    mode: 'LIVE_METADATA',
    upstreamErrors: errors.length ? errors : undefined,
  };
  await cacheSet(cacheKey, payload, 5 * 60_000);
  return payload;
}

export async function getAnime(id) {
  const mode = metadataMode();

  // Local demo / seeded titles first
  const local = safeLocalTitle(id);
  if (local && mode === 'demo') {
    return { title: local, source: 'demo', mode: 'DEMO' };
  }

  // mal-123 pattern
  const malMatch = String(id).match(/^mal-(\d+)$/);
  if (malMatch && mode !== 'demo') {
    const { result, provider, errors } = await tryProviders('getAnime', malMatch[1]);
    if (result) {
      try {
        const chars = await jikanProvider.getCharacters(malMatch[1]);
        result.characters = chars;
      } catch {
        /* */
      }
      try {
        const eps = await jikanProvider.getEpisodes(malMatch[1]);
        result.episodeList = eps.map((e) => ({
          id: e.id,
          seasonNumber: 1,
          episodeNumber: e.episodeNumber,
          name: e.name,
          runtime: result.runtime || 24,
        }));
      } catch {
        /* */
      }
      return { title: result, source: provider, mode: 'LIVE_METADATA' };
    }
    return {
      title: null,
      source: null,
      mode: 'LIVE_METADATA',
      error: { code: 'UPSTREAM_UNAVAILABLE', message: 'Anime metadata service temporarily unavailable', details: errors },
    };
  }

  // anilist-21
  const alMatch = String(id).match(/^anilist-(\d+)$/);
  if (alMatch && mode !== 'demo' && anilistProvider.enabled) {
    try {
      const title = await anilistProvider.getAnime(alMatch[1]);
      if (title) return { title, source: 'anilist', mode: 'LIVE_METADATA' };
    } catch (e) {
      return {
        title: local || null,
        source: local ? 'demo' : null,
        mode: local ? 'DEMO' : 'LIVE_METADATA',
        error: { code: e.code || 'UPSTREAM_ERROR', message: e.message },
      };
    }
  }

  // tmdb-tv-123
  const tmdbMatch = String(id).match(/^tmdb-(tv|movie)-(\d+)$/);
  if (tmdbMatch && tmdbProvider.enabled && mode !== 'demo') {
    try {
      const title = await tmdbProvider.getAnime(tmdbMatch[2], tmdbMatch[1]);
      if (title) return { title, source: 'tmdb', mode: 'LIVE_METADATA' };
    } catch (e) {
      return {
        title: local || null,
        source: local ? 'demo' : null,
        mode: local ? 'DEMO' : 'LIVE_METADATA',
        error: { code: e.code || 'UPSTREAM_ERROR', message: e.message },
      };
    }
  }

  if (local) return { title: local, source: 'demo', mode: 'DEMO' };
  return { title: null, source: null, mode, error: { code: 'NOT_FOUND', message: 'Title not found' } };
}

export async function getTrending(limit = 12) {
  if (metadataMode() === 'demo') {
    return { items: safeListTitles({ limit }).slice(0, limit), source: 'demo', mode: 'DEMO' };
  }
  const { result, provider, errors } = await tryProviders('getTrending', { limit });
  if (result?.length) return { items: result, source: provider, mode: 'LIVE_METADATA' };
  return {
    items: safeListTitles({ limit }).slice(0, limit),
    source: 'demo-fallback',
    mode: 'DEMO',
    upstreamErrors: errors,
  };
}

export async function getAiring(limit = 12) {
  if (metadataMode() === 'demo') {
    return {
      items: safeListTitles({ status: 'Airing', limit }),
      source: 'demo',
      mode: 'DEMO',
    };
  }
  const { result, provider, errors } = await tryProviders('getAiring', { limit });
  if (result?.length) return { items: result, source: provider, mode: 'LIVE_METADATA' };
  return {
    items: safeListTitles({ status: 'Airing', limit }),
    source: 'demo-fallback',
    mode: 'DEMO',
    upstreamErrors: errors,
  };
}

export async function getSeasonal(limit = 12) {
  if (metadataMode() === 'demo') {
    return { items: safeListTitles({ limit }), source: 'demo', mode: 'DEMO' };
  }
  const { result, provider, errors } = await tryProviders('getSeasonal', { limit });
  if (result?.length) return { items: result, source: provider, mode: 'LIVE_METADATA' };
  return {
    items: safeListTitles({ limit }),
    source: 'demo-fallback',
    mode: 'DEMO',
    upstreamErrors: errors,
  };
}

export async function getUpcoming(limit = 12) {
  if (metadataMode() === 'demo') {
    return { items: [], source: 'demo', mode: 'DEMO' };
  }
  const { result, provider, errors } = await tryProviders('getUpcoming', { limit });
  if (result?.length) return { items: result, source: provider, mode: 'LIVE_METADATA' };
  return { items: [], source: 'demo-fallback', mode: 'DEMO', upstreamErrors: errors };
}

export async function getRecommendationsFor(id, limit = 12) {
  if (metadataMode() === 'demo') {
    return {
      items: localCatalog.recommendations({ limit }),
      source: 'demo',
      mode: 'DEMO',
    };
  }
  const malMatch = String(id).match(/^mal-(\d+)$/);
  if (malMatch) {
    try {
      const items = await jikanProvider.getRecommendations(malMatch[1]);
      if (items.length) return { items: items.slice(0, limit), source: 'jikan', mode: 'LIVE_METADATA' };
    } catch {
      /* */
    }
    // AniList can resolve by MAL id for recs via media, then recommendations
    try {
      const alTitle = await anilistProvider.getAnimeByMal(malMatch[1]);
      if (alTitle?.externalIds?.anilist) {
        const items = await anilistProvider.getRecommendations(alTitle.externalIds.anilist);
        if (items.length) return { items: items.slice(0, limit), source: 'anilist', mode: 'LIVE_METADATA' };
      }
    } catch {
      /* */
    }
  }
  const alMatch = String(id).match(/^anilist-(\d+)$/);
  if (alMatch && anilistProvider.enabled) {
    try {
      const items = await anilistProvider.getRecommendations(alMatch[1]);
      if (items.length) return { items: items.slice(0, limit), source: 'anilist', mode: 'LIVE_METADATA' };
    } catch {
      /* */
    }
  }
  return {
    items: localCatalog.recommendations({ limit }),
    source: 'demo',
    mode: 'DEMO',
  };
}

export async function liveRails(profileId) {
  if (metadataMode() === 'demo') {
    return { rails: localCatalog.rails(profileId), mode: 'DEMO', source: 'demo' };
  }
  const [trending, airing, seasonal] = await Promise.all([
    getTrending(12),
    getAiring(12),
    getSeasonal(12),
  ]);
  const localRails = localCatalog.rails(profileId);
  return {
    rails: {
      continueWatching: localRails.continueWatching || [],
      trending: trending.items,
      newReleases: seasonal.items,
      airing: airing.items,
      gems: localRails.gems || [],
    },
    mode: 'LIVE_METADATA',
    sources: {
      trending: trending.source,
      airing: airing.source,
      seasonal: seasonal.source,
    },
  };
}

export function providerStatus() {
  return {
    mode: metadataMode(),
    demo: { available: true, note: 'mock.js / local SQLite seed when live providers fail or METADATA_MODE=demo' },
    jikan: {
      enabled: jikanProvider.enabled,
      configured: true,
      note: 'Primary MAL metadata (no API key)',
    },
    anilist: {
      enabled: anilistProvider.enabled,
      configured: true,
      note: 'GraphQL metadata fallback (no API key)',
    },
    tmdb: {
      enabled: tmdbProvider.enabled,
      configured: Boolean(process.env.TMDB_API_KEY),
      hasKey: Boolean(process.env.TMDB_API_KEY),
      note: 'Optional; requires TMDB_API_KEY',
    },
  };
}
