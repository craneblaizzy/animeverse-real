/**
 * Normalize upstream anime metadata into AnimeVerse card/detail shape.
 * Compatible with existing frontend mapTitle + posterGradient fallbacks.
 */

function yearFrom(dateStr) {
  if (!dateStr) return null;
  const y = parseInt(String(dateStr).slice(0, 4), 10);
  return Number.isFinite(y) ? y : null;
}

function statusMap(s) {
  if (!s) return 'Unknown';
  const x = String(s).toLowerCase();
  if (x.includes('airing') || x === 'currently airing') return 'Airing';
  if (x.includes('complete') || x === 'finished airing') return 'Completed';
  if (x.includes('upcoming') || x.includes('not yet')) return 'Upcoming';
  return s;
}

function typeMap(t) {
  if (!t) return 'series';
  const x = String(t).toLowerCase();
  if (x.includes('movie')) return 'movie';
  return 'series';
}

/** Stable internal id from MAL id */
export function internalIdFromMal(malId) {
  return `mal-${malId}`;
}

export function internalIdFromTmdb(tmdbId, mediaType = 'tv') {
  return `tmdb-${mediaType}-${tmdbId}`;
}

export function normalizeFromJikan(item) {
  if (!item) return null;
  const malId = item.mal_id;
  const images = item.images || {};
  const jpg = images.jpg || {};
  const webp = images.webp || {};
  const poster =
    jpg.large_image_url || jpg.image_url || webp.large_image_url || webp.image_url || null;
  const genres = (item.genres || []).map((g) => g.name).filter(Boolean);
  const themes = (item.themes || []).map((g) => g.name).filter(Boolean);
  const studios = (item.studios || []).map((s) => s.name).filter(Boolean);
  const title =
    item.title_english || item.title || item.title_japanese || `MAL ${malId}`;
  const altTitle = item.title_japanese || item.title || null;

  return {
    id: internalIdFromMal(malId),
    externalIds: { mal: String(malId), jikan: String(malId) },
    title,
    altTitle,
    type: typeMap(item.type),
    year: yearFrom(item.year || item.aired?.from),
    status: statusMap(item.status),
    rating: item.score != null ? Number(item.score) : 0,
    popularity: item.members || item.popularity || 0,
    episodes: item.episodes || 1,
    runtime: item.duration ? parseInt(String(item.duration), 10) || 24 : 24,
    studio: studios[0] || null,
    studios,
    genres,
    themes,
    description: item.synopsis || '',
    images: {
      poster,
      backdrop: poster,
      logo: null,
    },
    // Frontend falls back to gradient when no poster URL in older UI
    posterGradient: poster ? null : 'from-violet-700 via-indigo-800 to-slate-900',
    backdropGradient: poster ? null : 'from-indigo-950 via-void-950 to-void-950',
    posterUrl: poster,
    backdropUrl: poster,
    trailer: item.trailer?.url
      ? { url: item.trailer.url, type: item.trailer.embed_url ? 'embed' : 'url', embedUrl: item.trailer.embed_url || null }
      : null,
    season: item.season && item.year ? `${item.season} ${item.year}` : item.season || null,
    characters: [],
    staff: [],
    source: 'jikan',
    lastUpdated: new Date().toISOString(),
    progress: 0,
  };
}

export function normalizeAnimeListJikan(data) {
  const list = data?.data || data || [];
  return list.map(normalizeFromJikan).filter(Boolean);
}

export function normalizeFromTmdb(item, mediaType = 'tv') {
  if (!item) return null;
  const tmdbId = item.id;
  const posterPath = item.poster_path;
  const backdropPath = item.backdrop_path;
  const imgBase = 'https://image.tmdb.org/t/p';
  const poster = posterPath ? `${imgBase}/w500${posterPath}` : null;
  const backdrop = backdropPath ? `${imgBase}/w1280${backdropPath}` : poster;
  const title = item.name || item.title || `TMDB ${tmdbId}`;
  const genres = (item.genres || []).map((g) => g.name).filter(Boolean);

  return {
    id: internalIdFromTmdb(tmdbId, mediaType),
    externalIds: { tmdb: String(tmdbId) },
    title,
    altTitle: item.original_name || item.original_title || null,
    type: mediaType === 'movie' ? 'movie' : 'series',
    year: yearFrom(item.first_air_date || item.release_date),
    status: statusMap(item.status),
    rating: item.vote_average != null ? Number(item.vote_average) : 0,
    popularity: item.popularity || 0,
    episodes: item.number_of_episodes || 1,
    runtime: (item.episode_run_time && item.episode_run_time[0]) || item.runtime || 24,
    studio: null,
    studios: (item.networks || []).map((n) => n.name).filter(Boolean),
    genres,
    themes: [],
    description: item.overview || '',
    images: { poster, backdrop, logo: null },
    posterGradient: poster ? null : 'from-slate-700 to-void-900',
    backdropGradient: backdrop ? null : 'from-void-900 to-void-950',
    posterUrl: poster,
    backdropUrl: backdrop,
    trailer: null,
    season: null,
    characters: [],
    staff: [],
    source: 'tmdb',
    lastUpdated: new Date().toISOString(),
    progress: 0,
  };
}

export function normalizeAnimeListTmdb(results, mediaType = 'tv') {
  return (results || []).map((r) => normalizeFromTmdb(r, mediaType)).filter(Boolean);
}


export function internalIdFromAniList(anilistId) {
  return `anilist-${anilistId}`;
}

function stripHtml(s) {
  if (!s) return '';
  return String(s).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export function normalizeFromAniList(item) {
  if (!item) return null;
  const alId = item.id;
  const poster =
    item.coverImage?.extraLarge || item.coverImage?.large || item.coverImage?.medium || null;
  const backdrop = item.bannerImage || poster;
  const title =
    item.title?.english || item.title?.romaji || item.title?.native || `AniList ${alId}`;
  const altTitle = item.title?.native || item.title?.romaji || null;
  const studios = (item.studios?.nodes || []).map((s) => s.name).filter(Boolean);
  const genres = item.genres || [];
  let year = item.seasonYear || item.startDate?.year || null;
  let status = 'Unknown';
  const st = String(item.status || '').toUpperCase();
  if (st === 'RELEASING') status = 'Airing';
  else if (st === 'FINISHED') status = 'Completed';
  else if (st === 'NOT_YET_RELEASED') status = 'Upcoming';
  else if (st === 'CANCELLED') status = 'Cancelled';
  else if (st) status = item.status;

  const fmt = String(item.format || '').toUpperCase();
  const type = fmt === 'MOVIE' ? 'movie' : 'series';

  let trailer = null;
  if (item.trailer?.site && item.trailer?.id) {
    const site = String(item.trailer.site).toLowerCase();
    if (site === 'youtube') {
      trailer = {
        url: `https://www.youtube.com/watch?v=${item.trailer.id}`,
        type: 'youtube',
        embedUrl: `https://www.youtube.com/embed/${item.trailer.id}`,
      };
    } else {
      trailer = { url: null, type: site, embedUrl: null, id: item.trailer.id };
    }
  }

  const externalIds = { anilist: String(alId) };
  if (item.idMal) {
    externalIds.mal = String(item.idMal);
    externalIds.jikan = String(item.idMal);
  }

  // Prefer stable mal-* id when MAL link exists so watchlist can align with Jikan
  const id = item.idMal ? internalIdFromMal(item.idMal) : internalIdFromAniList(alId);

  return {
    id,
    externalIds,
    title,
    altTitle,
    type,
    year,
    status,
    rating: item.averageScore != null ? Number(item.averageScore) / 10 : 0,
    popularity: item.popularity || 0,
    episodes: item.episodes || 1,
    runtime: item.duration || 24,
    studio: studios[0] || null,
    studios,
    genres,
    themes: [],
    description: stripHtml(item.description),
    images: { poster, backdrop, logo: null },
    posterGradient: poster ? null : 'from-blue-700 via-indigo-800 to-slate-900',
    backdropGradient: backdrop ? null : 'from-indigo-950 via-void-950 to-void-950',
    posterUrl: poster,
    backdropUrl: backdrop,
    trailer,
    season: item.season && item.seasonYear ? `${String(item.season).toLowerCase()} ${item.seasonYear}` : null,
    characters: [],
    staff: [],
    source: 'anilist',
    lastUpdated: new Date().toISOString(),
    progress: 0,
  };
}

export function normalizeAnimeListAniList(list) {
  return (list || []).map(normalizeFromAniList).filter(Boolean);
}

/** Merge two normalized titles (prefer primary non-empty fields) */
export function mergeNormalized(primary, secondary) {
  if (!primary) return secondary;
  if (!secondary) return primary;
  return {
    ...secondary,
    ...primary,
    externalIds: { ...(secondary.externalIds || {}), ...(primary.externalIds || {}) },
    genres: [...new Set([...(primary.genres || []), ...(secondary.genres || [])])],
    themes: [...new Set([...(primary.themes || []), ...(secondary.themes || [])])],
    images: {
      poster: primary.images?.poster || secondary.images?.poster || null,
      backdrop: primary.images?.backdrop || secondary.images?.backdrop || null,
      logo: primary.images?.logo || secondary.images?.logo || null,
    },
    posterUrl: primary.posterUrl || secondary.posterUrl || null,
    backdropUrl: primary.backdropUrl || secondary.backdropUrl || null,
    trailer: primary.trailer || secondary.trailer || null,
    description: primary.description || secondary.description || '',
  };
}

export function dedupeByExternalIds(items) {
  const seen = new Set();
  const out = [];
  for (const it of items) {
    const keys = [];
    if (it.externalIds?.mal) keys.push(`mal:${it.externalIds.mal}`);
    if (it.externalIds?.anilist) keys.push(`anilist:${it.externalIds.anilist}`);
    if (it.externalIds?.tmdb) keys.push(`tmdb:${it.externalIds.tmdb}`);
    keys.push(`id:${it.id}`);
    const hit = keys.some((k) => seen.has(k));
    if (hit) continue;
    keys.forEach((k) => seen.add(k));
    out.push(it);
  }
  return out;
}
