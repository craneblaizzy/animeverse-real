/**
 * TMDB adapter — optional; requires TMDB_API_KEY.
 * Used for supplementary artwork / broader TV-movie metadata, not as sole anime source.
 */

import { cacheGet, cacheSet } from '../services/cache.js';
import { normalizeFromTmdb, normalizeAnimeListTmdb } from './normalize.js';

const BASE = process.env.TMDB_API_URL || 'https://api.themoviedb.org/3';
const KEY = process.env.TMDB_API_KEY || '';
const TIMEOUT_MS = Number(process.env.TMDB_TIMEOUT_MS) || 10000;
const TTL = Number(process.env.TMDB_TTL_MS) || 30 * 60_000;

async function tmdbFetch(path) {
  if (!KEY) {
    const err = new Error('TMDB_API_KEY not configured');
    err.code = 'PROVIDER_DISABLED';
    err.status = 503;
    throw err;
  }
  const sep = path.includes('?') ? '&' : '?';
  const url = `${BASE}${path}${sep}api_key=${encodeURIComponent(KEY)}`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { Accept: 'application/json' } });
    clearTimeout(timer);
    if (res.status === 429) {
      const err = new Error('TMDB rate limited');
      err.code = 'UPSTREAM_RATE_LIMIT';
      err.status = 429;
      throw err;
    }
    if (!res.ok) {
      const err = new Error(`TMDB HTTP ${res.status}`);
      err.code = 'UPSTREAM_ERROR';
      err.status = res.status;
      throw err;
    }
    return await res.json();
  } catch (e) {
    clearTimeout(timer);
    if (e.name === 'AbortError') {
      const err = new Error('TMDB timeout');
      err.code = 'UPSTREAM_TIMEOUT';
      err.status = 504;
      throw err;
    }
    throw e;
  }
}

async function cached(key, fn) {
  const hit = await cacheGet(key);
  if (hit != null) return hit;
  const data = await fn();
  await cacheSet(key, data, TTL);
  return data;
}

export const tmdbProvider = {
  name: 'tmdb',
  enabled: Boolean(KEY) && process.env.TMDB_ENABLED !== '0',

  async searchAnime(q, { limit = 12 } = {}) {
    if (!this.enabled || !q?.trim()) return [];
    const key = `tmdb:search:${q.trim().toLowerCase()}:${limit}`;
    const data = await cached(key, () =>
      tmdbFetch(`/search/tv?query=${encodeURIComponent(q.trim())}&include_adult=false`)
    );
    return normalizeAnimeListTmdb((data.results || []).slice(0, limit), 'tv');
  },

  async getAnime(tmdbId, mediaType = 'tv') {
    if (!this.enabled) return null;
    const key = `tmdb:${mediaType}:${tmdbId}`;
    const data = await cached(key, () => tmdbFetch(`/${mediaType}/${tmdbId}`));
    return normalizeFromTmdb(data, mediaType);
  },

  async getTrending({ limit = 12 } = {}) {
    if (!this.enabled) return [];
    const key = `tmdb:trending:${limit}`;
    const data = await cached(key, () => tmdbFetch('/trending/tv/week'));
    return normalizeAnimeListTmdb((data.results || []).slice(0, limit), 'tv');
  },

  async getRecommendations() {
    return [];
  },

  async getCharacters() {
    return [];
  },

  async getEpisodes() {
    return [];
  },

  async getAiring() {
    return [];
  },

  async getUpcoming() {
    return [];
  },

  async getSeasonal() {
    return [];
  },
};
