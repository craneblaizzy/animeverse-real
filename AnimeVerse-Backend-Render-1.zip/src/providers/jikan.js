/**
 * Jikan (unofficial MyAnimeList) adapter — public API, no key required.
 * Rate limit: ~3 req/sec recommended; we serialize with min interval + cache.
 */

import { cacheGet, cacheSet } from '../services/cache.js';
import { normalizeFromJikan, normalizeAnimeListJikan } from './normalize.js';

const BASE = process.env.JIKAN_API_URL || 'https://api.jikan.moe/v4';
const MIN_INTERVAL_MS = Number(process.env.JIKAN_MIN_INTERVAL_MS) || 400;
const TIMEOUT_MS = Number(process.env.JIKAN_TIMEOUT_MS) || 12000;
const TTL_SEARCH = Number(process.env.JIKAN_TTL_SEARCH_MS) || 10 * 60_000;
const TTL_DETAIL = Number(process.env.JIKAN_TTL_DETAIL_MS) || 60 * 60_000;
const TTL_LIST = Number(process.env.JIKAN_TTL_LIST_MS) || 15 * 60_000;

let lastCall = 0;
let circuitOpenUntil = 0;
let consecutiveFails = 0;

async function throttle() {
  const wait = MIN_INTERVAL_MS - (Date.now() - lastCall);
  if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  lastCall = Date.now();
}

async function jikanFetch(path) {
  if (Date.now() < circuitOpenUntil) {
    const err = new Error('Jikan circuit open — try later');
    err.code = 'UPSTREAM_CIRCUIT';
    err.status = 503;
    throw err;
  }
  await throttle();
  const url = `${BASE}${path}`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { Accept: 'application/json', 'User-Agent': 'AnimeVerse/1.0 (demo; +https://localhost)' },
    });
    clearTimeout(timer);
    if (res.status === 429) {
      consecutiveFails += 1;
      circuitOpenUntil = Date.now() + 30_000;
      const err = new Error('Jikan rate limited');
      err.code = 'UPSTREAM_RATE_LIMIT';
      err.status = 429;
      throw err;
    }
    if (!res.ok) {
      consecutiveFails += 1;
      if (consecutiveFails >= 5) circuitOpenUntil = Date.now() + 60_000;
      const err = new Error(`Jikan HTTP ${res.status}`);
      err.code = 'UPSTREAM_ERROR';
      err.status = res.status;
      throw err;
    }
    consecutiveFails = 0;
    return await res.json();
  } catch (e) {
    clearTimeout(timer);
    if (e.name === 'AbortError') {
      const err = new Error('Jikan timeout');
      err.code = 'UPSTREAM_TIMEOUT';
      err.status = 504;
      throw err;
    }
    throw e;
  }
}

async function cached(key, ttl, fn) {
  const hit = await cacheGet(key);
  if (hit != null) return hit;
  const data = await fn();
  await cacheSet(key, data, ttl);
  return data;
}

export const jikanProvider = {
  name: 'jikan',
  enabled: process.env.JIKAN_ENABLED !== '0',

  async searchAnime(q, { limit = 12, page = 1 } = {}) {
    if (!this.enabled || !q?.trim()) return [];
    const key = `jikan:search:${q.trim().toLowerCase()}:${limit}:${page}`;
    const data = await cached(key, TTL_SEARCH, () =>
      jikanFetch(`/anime?q=${encodeURIComponent(q.trim())}&limit=${limit}&page=${page}&sfw=true`)
    );
    return normalizeAnimeListJikan(data);
  },

  async getAnime(malId) {
    if (!this.enabled) return null;
    const key = `jikan:anime:${malId}`;
    const data = await cached(key, TTL_DETAIL, () => jikanFetch(`/anime/${malId}/full`));
    return normalizeFromJikan(data?.data || data);
  },

  async getCharacters(malId) {
    if (!this.enabled) return [];
    const key = `jikan:chars:${malId}`;
    const data = await cached(key, TTL_DETAIL, () => jikanFetch(`/anime/${malId}/characters`));
    return (data?.data || []).slice(0, 24).map((c) => ({
      id: `mal-char-${c.character?.mal_id}`,
      name: c.character?.name,
      role: c.role,
      image: c.character?.images?.jpg?.image_url || null,
    }));
  },

  async getEpisodes(malId, page = 1) {
    if (!this.enabled) return [];
    const key = `jikan:eps:${malId}:${page}`;
    const data = await cached(key, TTL_DETAIL, () =>
      jikanFetch(`/anime/${malId}/episodes?page=${page}`)
    );
    return (data?.data || []).map((e) => ({
      id: `mal-${malId}-ep-${e.mal_id || e.episode}`,
      episodeNumber: e.mal_id || e.episode,
      name: e.title || `Episode ${e.mal_id || e.episode}`,
      aired: e.aired || null,
      score: e.score || null,
    }));
  },

  async getRecommendations(malId) {
    if (!this.enabled) return [];
    const key = `jikan:rec:${malId}`;
    const data = await cached(key, TTL_LIST, () => jikanFetch(`/anime/${malId}/recommendations`));
    return (data?.data || []).slice(0, 12).map((r) => normalizeFromJikan(r.entry)).filter(Boolean);
  },

  async getTrending({ limit = 12 } = {}) {
    if (!this.enabled) return [];
    const key = `jikan:top:${limit}`;
    const data = await cached(key, TTL_LIST, () =>
      jikanFetch(`/top/anime?filter=bypopularity&limit=${limit}`)
    );
    return normalizeAnimeListJikan(data);
  },

  async getAiring({ limit = 12 } = {}) {
    if (!this.enabled) return [];
    const key = `jikan:airing:${limit}`;
    const data = await cached(key, TTL_LIST, () =>
      jikanFetch(`/top/anime?filter=airing&limit=${limit}`)
    );
    return normalizeAnimeListJikan(data);
  },

  async getUpcoming({ limit = 12 } = {}) {
    if (!this.enabled) return [];
    const key = `jikan:upcoming:${limit}`;
    const data = await cached(key, TTL_LIST, () =>
      jikanFetch(`/top/anime?filter=upcoming&limit=${limit}`)
    );
    return normalizeAnimeListJikan(data);
  },

  async getSeasonal({ limit = 12 } = {}) {
    if (!this.enabled) return [];
    const key = `jikan:season:now:${limit}`;
    const data = await cached(key, TTL_LIST, () => jikanFetch(`/seasons/now?limit=${limit}`));
    return normalizeAnimeListJikan(data);
  },
};
