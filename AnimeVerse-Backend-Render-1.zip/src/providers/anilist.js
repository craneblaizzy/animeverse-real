/**
 * AniList GraphQL adapter — public API, no key required for read queries.
 * Priority: after Jikan, before TMDB. Metadata only (no streaming).
 */

import { cacheGet, cacheSet } from '../services/cache.js';
import { normalizeFromAniList, normalizeAnimeListAniList } from './normalize.js';

const ENDPOINT = process.env.ANILIST_API_URL || 'https://graphql.anilist.co';
const MIN_INTERVAL_MS = Number(process.env.ANILIST_MIN_INTERVAL_MS) || 350;
const TIMEOUT_MS = Number(process.env.ANILIST_TIMEOUT_MS) || 12000;
const TTL_SEARCH = Number(process.env.ANILIST_TTL_SEARCH_MS) || 10 * 60_000;
const TTL_DETAIL = Number(process.env.ANILIST_TTL_DETAIL_MS) || 60 * 60_000;
const TTL_LIST = Number(process.env.ANILIST_TTL_LIST_MS) || 15 * 60_000;

let lastCall = 0;
let circuitOpenUntil = 0;
let consecutiveFails = 0;

const MEDIA_FIELDS = `
  id
  idMal
  type
  format
  status
  episodes
  duration
  averageScore
  popularity
  season
  seasonYear
  description(asHtml: false)
  genres
  startDate { year month day }
  title { romaji english native }
  coverImage { large extraLarge }
  bannerImage
  trailer { id site thumbnail }
  studios(isMain: true) { nodes { id name } }
  externalLinks { site url }
`;

async function throttle() {
  const wait = MIN_INTERVAL_MS - (Date.now() - lastCall);
  if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  lastCall = Date.now();
}

async function anilistQuery(query, variables = {}) {
  if (Date.now() < circuitOpenUntil) {
    const err = new Error('AniList circuit open — try later');
    err.code = 'UPSTREAM_CIRCUIT';
    err.status = 503;
    throw err;
  }
  await throttle();
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(ENDPOINT, {
      method: 'POST',
      signal: ctrl.signal,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'User-Agent': 'AnimeVerse/1.0 (demo; metadata-only)',
      },
      body: JSON.stringify({ query, variables }),
    });
    clearTimeout(timer);
    if (res.status === 429) {
      consecutiveFails += 1;
      circuitOpenUntil = Date.now() + 30_000;
      const err = new Error('AniList rate limited');
      err.code = 'UPSTREAM_RATE_LIMIT';
      err.status = 429;
      throw err;
    }
    if (!res.ok) {
      consecutiveFails += 1;
      if (consecutiveFails >= 5) circuitOpenUntil = Date.now() + 60_000;
      const err = new Error(`AniList HTTP ${res.status}`);
      err.code = 'UPSTREAM_ERROR';
      err.status = res.status;
      throw err;
    }
    const json = await res.json();
    if (json.errors?.length) {
      consecutiveFails += 1;
      const err = new Error(json.errors[0].message || 'AniList GraphQL error');
      err.code = 'UPSTREAM_ERROR';
      err.status = 502;
      throw err;
    }
    consecutiveFails = 0;
    return json.data;
  } catch (e) {
    clearTimeout(timer);
    if (e.name === 'AbortError') {
      const err = new Error('AniList timeout');
      err.code = 'UPSTREAM_TIMEOUT';
      err.status = 504;
      throw err;
    }
    throw e;
  }
}

async function cached(key, ttl, fn) {
  const hit = await cacheGet(key);
  if (hit != null) return hit;
  const data = await fn();
  await cacheSet(key, data, ttl);
  return data;
}

export const anilistProvider = {
  name: 'anilist',
  enabled: process.env.ANILIST_ENABLED !== '0',

  async searchAnime(q, { limit = 12, page = 1 } = {}) {
    if (!this.enabled || !q?.trim()) return [];
    const key = `anilist:search:${q.trim().toLowerCase()}:${limit}:${page}`;
    const data = await cached(key, TTL_SEARCH, () =>
      anilistQuery(
        `query ($search: String, $page: Int, $perPage: Int) {
          Page(page: $page, perPage: $perPage) {
            media(search: $search, type: ANIME, sort: SEARCH_MATCH) {
              ${MEDIA_FIELDS}
            }
          }
        }`,
        { search: q.trim(), page, perPage: Math.min(Number(limit) || 12, 25) }
      )
    );
    return normalizeAnimeListAniList(data?.Page?.media);
  },

  async getAnime(anilistId) {
    if (!this.enabled) return null;
    const id = Number(anilistId);
    if (!Number.isFinite(id)) return null;
    const key = `anilist:anime:${id}`;
    const data = await cached(key, TTL_DETAIL, () =>
      anilistQuery(
        `query ($id: Int) {
          Media(id: $id, type: ANIME) {
            ${MEDIA_FIELDS}
          }
        }`,
        { id }
      )
    );
    return normalizeFromAniList(data?.Media);
  },

  /** Optional: resolve by MAL id when linked on AniList */
  async getAnimeByMal(malId) {
    if (!this.enabled) return null;
    const id = Number(malId);
    if (!Number.isFinite(id)) return null;
    const key = `anilist:byMal:${id}`;
    const data = await cached(key, TTL_DETAIL, () =>
      anilistQuery(
        `query ($idMal: Int) {
          Media(idMal: $idMal, type: ANIME) {
            ${MEDIA_FIELDS}
          }
        }`,
        { idMal: id }
      )
    );
    return normalizeFromAniList(data?.Media);
  },

  async getCharacters() {
    return [];
  },

  async getEpisodes() {
    return [];
  },

  async getRecommendations(anilistId) {
    if (!this.enabled) return [];
    const id = Number(anilistId);
    if (!Number.isFinite(id)) return [];
    const key = `anilist:rec:${id}`;
    const data = await cached(key, TTL_LIST, () =>
      anilistQuery(
        `query ($id: Int) {
          Media(id: $id, type: ANIME) {
            recommendations(page: 1, perPage: 12) {
              nodes {
                mediaRecommendation {
                  ${MEDIA_FIELDS}
                }
              }
            }
          }
        }`,
        { id }
      )
    );
    const nodes = data?.Media?.recommendations?.nodes || [];
    return nodes
      .map((n) => normalizeFromAniList(n.mediaRecommendation))
      .filter(Boolean);
  },

  async getTrending({ limit = 12 } = {}) {
    if (!this.enabled) return [];
    const key = `anilist:trending:${limit}`;
    const data = await cached(key, TTL_LIST, () =>
      anilistQuery(
        `query ($perPage: Int) {
          Page(page: 1, perPage: $perPage) {
            media(type: ANIME, sort: TRENDING_DESC) {
              ${MEDIA_FIELDS}
            }
          }
        }`,
        { perPage: Math.min(Number(limit) || 12, 25) }
      )
    );
    return normalizeAnimeListAniList(data?.Page?.media);
  },

  async getAiring({ limit = 12 } = {}) {
    if (!this.enabled) return [];
    const key = `anilist:airing:${limit}`;
    const data = await cached(key, TTL_LIST, () =>
      anilistQuery(
        `query ($perPage: Int) {
          Page(page: 1, perPage: $perPage) {
            media(type: ANIME, status: RELEASING, sort: POPULARITY_DESC) {
              ${MEDIA_FIELDS}
            }
          }
        }`,
        { perPage: Math.min(Number(limit) || 12, 25) }
      )
    );
    return normalizeAnimeListAniList(data?.Page?.media);
  },

  async getUpcoming({ limit = 12 } = {}) {
    if (!this.enabled) return [];
    const key = `anilist:upcoming:${limit}`;
    const data = await cached(key, TTL_LIST, () =>
      anilistQuery(
        `query ($perPage: Int) {
          Page(page: 1, perPage: $perPage) {
            media(type: ANIME, status: NOT_YET_RELEASED, sort: POPULARITY_DESC) {
              ${MEDIA_FIELDS}
            }
          }
        }`,
        { perPage: Math.min(Number(limit) || 12, 25) }
      )
    );
    return normalizeAnimeListAniList(data?.Page?.media);
  },

  async getSeasonal({ limit = 12 } = {}) {
    if (!this.enabled) return [];
    const now = new Date();
    const month = now.getMonth() + 1;
    let season = 'WINTER';
    if (month >= 4 && month <= 6) season = 'SPRING';
    else if (month >= 7 && month <= 9) season = 'SUMMER';
    else if (month >= 10 && month <= 12) season = 'FALL';
    const year = now.getFullYear();
    const key = `anilist:season:${year}:${season}:${limit}`;
    const data = await cached(key, TTL_LIST, () =>
      anilistQuery(
        `query ($season: MediaSeason, $seasonYear: Int, $perPage: Int) {
          Page(page: 1, perPage: $perPage) {
            media(type: ANIME, season: $season, seasonYear: $seasonYear, sort: POPULARITY_DESC) {
              ${MEDIA_FIELDS}
            }
          }
        }`,
        { season, seasonYear: year, perPage: Math.min(Number(limit) || 12, 25) }
      )
    );
    return normalizeAnimeListAniList(data?.Page?.media);
  },
};
