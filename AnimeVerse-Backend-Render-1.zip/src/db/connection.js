/**
 * SQLite via Node.js built-in node:sqlite (no native compile).
 * API is sync-compatible enough for our small schema.
 */
import { DatabaseSync } from 'node:sqlite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.resolve(__dirname, '../../data');
const dbPath = process.env.DATABASE_PATH || path.join(dataDir, 'animeverse.sqlite');

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(dbPath);
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

/** Thin wrapper so call sites keep better-sqlite3-style prepare/run/get/all */
function wrapStmt(stmt) {
  return {
    run(...params) {
      const r = stmt.run(...params);
      return { changes: r.changes, lastInsertRowid: r.lastInsertRowid };
    },
    get(...params) {
      return stmt.get(...params);
    },
    all(...params) {
      return stmt.all(...params);
    },
  };
}

const api = {
  prepare(sql) {
    return wrapStmt(db.prepare(sql));
  },
  exec(sql) {
    return db.exec(sql);
  },
  transaction(fn) {
    return (...args) => {
      db.exec('BEGIN');
      try {
        const result = fn(...args);
        db.exec('COMMIT');
        return result;
      } catch (e) {
        db.exec('ROLLBACK');
        throw e;
      }
    };
  },
  close() {
    db.close();
  },
  pragma(key) {
    /* no-op / already set */
  },
};

export function getDb() {
  return api;
}

export function getDbPath() {
  return dbPath;
}
