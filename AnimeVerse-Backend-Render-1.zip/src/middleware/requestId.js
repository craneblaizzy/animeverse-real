import { randomUUID } from 'crypto';

export function requestId(req, res, next) {
  const id = req.headers['x-request-id'] || randomUUID().slice(0, 12);
  req.requestId = id;
  res.setHeader('X-Request-Id', id);
  next();
}
