/**
 * Simple in-memory sliding-window rate limiter (per IP + optional user).
 * Production: replace with Redis.
 */
const buckets = new Map();

const WINDOW_MS = Number(process.env.RATE_WINDOW_MS) || 60_000;
const MAX_REQ = Number(process.env.RATE_MAX) || 120;

function keyFor(req) {
  const ip = req.ip || req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'unknown';
  const uid = req.user?.sub || '';
  return `${ip}:${uid}`;
}

export function rateLimit(req, res, next) {
  const key = keyFor(req);
  const now = Date.now();
  let bucket = buckets.get(key);
  if (!bucket || now - bucket.start > WINDOW_MS) {
    bucket = { start: now, count: 0 };
    buckets.set(key, bucket);
  }
  bucket.count += 1;
  res.setHeader('X-RateLimit-Limit', String(MAX_REQ));
  res.setHeader('X-RateLimit-Remaining', String(Math.max(0, MAX_REQ - bucket.count)));
  if (bucket.count > MAX_REQ) {
    return res.status(429).json({
      error: 'RateLimitExceeded',
      message: 'Too many requests. Slow down.',
      retryAfterSec: Math.ceil((WINDOW_MS - (now - bucket.start)) / 1000),
    });
  }
  next();
}

/** Periodic cleanup to avoid unbounded memory */
setInterval(() => {
  const now = Date.now();
  for (const [k, b] of buckets) {
    if (now - b.start > WINDOW_MS * 2) buckets.delete(k);
  }
}, WINDOW_MS).unref?.();
