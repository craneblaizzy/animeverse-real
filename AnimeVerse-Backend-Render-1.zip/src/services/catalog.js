import { getDb } from '../db/connection.js';

function mapTitle(row, genres = []) {
  if (!row) return null;
  let themes = [];
  try {
    themes = JSON.parse(row.themes_json || '[]');
  } catch {
    themes = [];
  }
  return {
    id: row.id,
    title: row.title,
    altTitle: row.alt_title,
    type: row.type,
    year: row.year,
    status: row.status,
    rating: row.rating,
    episodes: row.episodes,
    runtime: row.runtime,
    studio: row.studio_name,
    description: row.description,
    posterGradient: row.poster_gradient,
    backdropGradient: row.backdrop_gradient,
    season: row.season_label,
    tone: row.tone,
    pacing: row.pacing,
    themes,
    genres,
  };
}

function genresForTitle(titleId) {
  return getDb()
    .prepare(
      `SELECT g.name FROM genres g
       JOIN title_genres tg ON tg.genre_id = g.id
       WHERE tg.title_id = ? ORDER BY g.name`
    )
    .all(titleId)
    .map((r) => r.name);
}

export function listGenres() {
  return getDb().prepare('SELECT id, name, color FROM genres ORDER BY name').all();
}

export function listStudios() {
  return getDb().prepare('SELECT id, name FROM studios ORDER BY name').all();
}

/**
 * Advanced list/search with facets.
 * Query: status, genre, q, year, studio, type, tone, pacing, minRating, limit, offset, sort
 */
export function listTitles(opts = {}) {
  const {
    status,
    genre,
    q,
    year,
    studio,
    type,
    tone,
    pacing,
    minRating,
    limit = 50,
    offset = 0,
    sort = 'rating',
  } = opts;
  const db = getDb();
  let sql = `
    SELECT DISTINCT t.* FROM titles t
    LEFT JOIN title_genres tg ON tg.title_id = t.id
    LEFT JOIN genres g ON g.id = tg.genre_id
    WHERE t.published = 1
  `;
  const params = [];

  if (status) {
    sql += ' AND t.status = ?';
    params.push(status);
  }
  if (genre) {
    sql += ' AND (g.name = ? OR g.id = ?)';
    params.push(genre, genre);
  }
  if (q) {
    sql +=
      ' AND (t.title LIKE ? OR t.alt_title LIKE ? OR t.studio_name LIKE ? OR t.description LIKE ? OR t.tone LIKE ? OR t.themes_json LIKE ?)';
    const like = `%${q}%`;
    params.push(like, like, like, like, like, like);
  }
  if (year) {
    sql += ' AND t.year = ?';
    params.push(Number(year));
  }
  if (studio) {
    sql += ' AND (t.studio_name LIKE ? OR t.studio_id = ?)';
    params.push(`%${studio}%`, studio);
  }
  if (type) {
    sql += ' AND t.type = ?';
    params.push(type);
  }
  if (tone) {
    sql += ' AND t.tone LIKE ?';
    params.push(`%${tone}%`);
  }
  if (pacing) {
    sql += ' AND t.pacing LIKE ?';
    params.push(`%${pacing}%`);
  }
  if (minRating != null && minRating !== '') {
    sql += ' AND t.rating >= ?';
    params.push(Number(minRating));
  }

  const orderMap = {
    rating: 't.rating DESC, t.year DESC',
    year: 't.year DESC, t.rating DESC',
    title: 't.title ASC',
    episodes: 't.episodes DESC',
  };
  sql += ` ORDER BY ${orderMap[sort] || orderMap.rating} LIMIT ? OFFSET ?`;
  params.push(Math.min(Number(limit) || 50, 100), Number(offset) || 0);

  const rows = db.prepare(sql).all(...params);
  return rows.map((row) => mapTitle(row, genresForTitle(row.id)));
}

/** Facet aggregates for search UI */
export function searchFacets(q) {
  const db = getDb();
  const base = listTitles({ q, limit: 200 });
  const years = {};
  const studios = {};
  const types = {};
  const statuses = {};
  const tones = {};
  const genres = {};

  for (const t of base) {
    if (t.year) years[t.year] = (years[t.year] || 0) + 1;
    if (t.studio) studios[t.studio] = (studios[t.studio] || 0) + 1;
    if (t.type) types[t.type] = (types[t.type] || 0) + 1;
    if (t.status) statuses[t.status] = (statuses[t.status] || 0) + 1;
    if (t.tone) tones[t.tone] = (tones[t.tone] || 0) + 1;
    for (const g of t.genres || []) genres[g] = (genres[g] || 0) + 1;
  }

  const toArr = (obj) =>
    Object.entries(obj)
      .map(([value, count]) => ({ value, count }))
      .sort((a, b) => b.count - a.count);

  return {
    total: base.length,
    years: toArr(years),
    studios: toArr(studios),
    types: toArr(types),
    statuses: toArr(statuses),
    tones: toArr(tones),
    genres: toArr(genres),
  };
}

export function getTitle(id) {
  const row = getDb().prepare('SELECT * FROM titles WHERE id = ? AND published = 1').get(id);
  if (!row) return null;
  const title = mapTitle(row, genresForTitle(id));
  title.episodeList = getDb()
    .prepare(
      `SELECT id, season_number AS seasonNumber, episode_number AS episodeNumber, name, runtime,
              intro_start_ms AS introStartMs, intro_end_ms AS introEndMs, air_date AS airDate
       FROM episodes WHERE title_id = ? ORDER BY season_number, episode_number`
    )
    .all(id);

  const rev = getDb()
    .prepare(
      `SELECT AVG(rating) AS avgRating, COUNT(*) AS reviewCount
       FROM reviews WHERE title_id = ? AND status = 'visible'`
    )
    .get(id);
  title.communityRating = rev?.avgRating ? Math.round(rev.avgRating * 10) / 10 : null;
  title.reviewCount = rev?.reviewCount || 0;
  return title;
}

export function rails(profileId) {
  const db = getDb();
  const all = listTitles({ limit: 100 });
  const byRating = [...all].sort((a, b) => b.rating - a.rating);
  const maxYear = Math.max(0, ...all.map((t) => t.year || 0));

  let continueItems = [];
  if (profileId) {
    const rows = db
      .prepare(
        `SELECT t.id, MAX(wp.position_ms * 1.0 / NULLIF(wp.duration_ms, 0)) AS prog
         FROM watch_progress wp
         JOIN episodes e ON e.id = wp.episode_id
         JOIN titles t ON t.id = e.title_id
         WHERE wp.profile_id = ? AND wp.completed = 0
         GROUP BY t.id`
      )
      .all(profileId);
    continueItems = rows
      .map((r) => {
        const t = all.find((x) => x.id === r.id);
        if (!t) return null;
        return { ...t, progress: Math.min(0.99, Math.max(0.01, r.prog || 0.1)) };
      })
      .filter(Boolean);
  }

  return {
    continueWatching: continueItems,
    trending: byRating.slice(0, 12),
    newReleases: all.filter((t) => t.year === maxYear).slice(0, 12),
    airing: all.filter((t) => t.status === 'Airing'),
    gems: all.filter((t) => t.rating >= 8 && t.rating < 9).slice(0, 10),
  };
}

/**
 * Mood + preference recommendations.
 * mood examples: epic, chill, dark, romantic, funny
 */
export function recommendations({ profileId, mood, limit = 12 } = {}) {
  const all = listTitles({ limit: 100 });
  const db = getDb();

  let preferredGenres = new Set();
  if (profileId) {
    const prefs = db
      .prepare(
        `SELECT g.name FROM profile_preferences pp
         JOIN genres g ON g.id = pp.genre_id WHERE pp.profile_id = ?`
      )
      .all(profileId);
    preferredGenres = new Set(prefs.map((p) => p.name));

    const watchedGenres = db
      .prepare(
        `SELECT g.name, COUNT(*) AS c FROM watch_progress wp
         JOIN episodes e ON e.id = wp.episode_id
         JOIN title_genres tg ON tg.title_id = e.title_id
         JOIN genres g ON g.id = tg.genre_id
         WHERE wp.profile_id = ?
         GROUP BY g.name ORDER BY c DESC LIMIT 5`
      )
      .all(profileId);
    for (const w of watchedGenres) preferredGenres.add(w.name);
  }

  const moodMap = {
    epic: ['Action', 'Adventure', 'Fantasy', 'Sci-Fi'],
    chill: ['Slice of Life', 'Comedy', 'Romance'],
    dark: ['Thriller', 'Horror', 'Mystery', 'Drama'],
    romantic: ['Romance', 'Drama', 'Slice of Life'],
    funny: ['Comedy', 'Slice of Life'],
    intense: ['Action', 'Thriller', 'Sports'],
  };
  const moodGenres = mood && moodMap[String(mood).toLowerCase()] ? new Set(moodMap[String(mood).toLowerCase()]) : null;

  const scored = all.map((t) => {
    let score = t.rating || 0;
    for (const g of t.genres || []) {
      if (preferredGenres.has(g)) score += 1.5;
      if (moodGenres && moodGenres.has(g)) score += 2;
    }
    if (mood) {
      const tone = (t.tone || '').toLowerCase();
      if (mood === 'epic' && tone.includes('epic')) score += 1;
      if (mood === 'chill' && (tone.includes('warm') || tone.includes('gentle'))) score += 1;
      if (mood === 'dark' && (tone.includes('dark') || tone.includes('grim'))) score += 1;
    }
    return { ...t, score };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, Math.min(Number(limit) || 12, 30));
}

/** Week radar: airing titles + schedule + profile alerts */
export function radarWeek(profileId) {
  const db = getDb();
  const airing = listTitles({ status: 'Airing', limit: 50 });
  const schedule = db
    .prepare(
      `SELECT s.title_id AS titleId, s.weekday, s.time_utc AS timeUtc, s.episode_hint AS episodeHint, t.title
       FROM air_schedule s JOIN titles t ON t.id = s.title_id`
    )
    .all();

  let alerts = [];
  if (profileId) {
    alerts = db
      .prepare(
        `SELECT a.title_id AS titleId, t.title, a.enabled
         FROM radar_alerts a JOIN titles t ON t.id = a.title_id
         WHERE a.profile_id = ?`
      )
      .all(profileId);
  }

  const byDay = Array.from({ length: 7 }, (_, weekday) => ({
    weekday,
    label: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][weekday],
    slots: schedule
      .filter((s) => s.weekday === weekday)
      .map((s) => ({
        ...s,
        alerted: alerts.some((a) => a.titleId === s.titleId && a.enabled),
      })),
  }));

  return {
    week: byDay,
    airing,
    alerts,
  };
}

export function charactersForTitle(titleId) {
  return getDb()
    .prepare(
      `SELECT id, name, role, bio, color FROM characters WHERE title_id = ? ORDER BY
       CASE role WHEN 'protagonist' THEN 0 WHEN 'antagonist' THEN 1 ELSE 2 END, name`
    )
    .all(titleId);
}

export function getStudio(idOrName) {
  const db = getDb();
  const studio =
    db.prepare('SELECT id, name FROM studios WHERE id = ? OR name = ?').get(idOrName, idOrName) ||
    null;
  if (!studio) return null;
  const titles = listTitles({ studio: studio.name, limit: 50 });
  return { ...studio, titles, count: titles.length };
}

/** Cached rails — used by route layer */
export async function railsCached(profileId) {
  const { cacheGet, cacheSet } = await import('./cache.js');
  const key = `rails:${profileId || 'anon'}`;
  const hit = await cacheGet(key);
  if (hit) return hit;
  const data = rails(profileId);
  await cacheSet(key, data, Number(process.env.CACHE_RAILS_TTL_MS) || 30_000);
  return data;
}
