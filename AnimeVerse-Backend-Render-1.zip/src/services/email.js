/**
 * Email provider adapter.
 * Default: console/log transport (dev).
 * Production: set EMAIL_PROVIDER=smtp|ses|sendgrid + credentials.
 */

const provider = process.env.EMAIL_PROVIDER || 'console';
const from = process.env.EMAIL_FROM || 'noreply@animeverse.local';

const outbox = [];

export function getOutbox() {
  return [...outbox].slice(-50);
}

export async function sendEmail({ to, subject, text, html }) {
  const msg = {
    id: `msg_${Date.now()}`,
    to,
    from,
    subject,
    text: text || '',
    html: html || null,
    provider,
    sentAt: new Date().toISOString(),
  };

  if (provider === 'console' || provider === 'dev') {
    console.log('[email:console]', JSON.stringify({ to, subject, text: text?.slice(0, 120) }));
    outbox.push(msg);
    return { ok: true, ...msg };
  }

  if (provider === 'sendgrid') {
    const key = process.env.SENDGRID_API_KEY;
    if (!key) throw new Error('SENDGRID_API_KEY required');
    // Stub: real integration would fetch SendGrid API
    console.log('[email:sendgrid:stub]', { to, subject });
    outbox.push({ ...msg, note: 'stub — wire @sendgrid/mail in production' });
    return { ok: true, ...msg, stub: true };
  }

  if (provider === 'ses') {
    console.log('[email:ses:stub]', { to, subject });
    outbox.push({ ...msg, note: 'stub — wire AWS SES SDK in production' });
    return { ok: true, ...msg, stub: true };
  }

  if (provider === 'smtp') {
    console.log('[email:smtp:stub]', { to, subject, host: process.env.SMTP_HOST });
    outbox.push({ ...msg, note: 'stub — wire nodemailer in production' });
    return { ok: true, ...msg, stub: true };
  }

  throw new Error(`Unknown EMAIL_PROVIDER: ${provider}`);
}

export async function sendPasswordReset(email, token) {
  const base = process.env.APP_URL || 'http://localhost:5173';
  return sendEmail({
    to: email,
    subject: 'AnimeVerse password reset',
    text: `Reset your password: ${base}/reset?token=${token}\nThis link expires in 1 hour.`,
  });
}

export async function sendEmailVerification(email, token) {
  const base = process.env.APP_URL || 'http://localhost:5173';
  return sendEmail({
    to: email,
    subject: 'Verify your AnimeVerse email',
    text: `Verify: ${base}/verify?token=${token}`,
  });
}
