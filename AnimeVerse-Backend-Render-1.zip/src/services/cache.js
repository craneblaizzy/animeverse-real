/**
 * Cache layer with Redis-compatible interface.
 * Uses in-memory Map by default; set REDIS_URL to enable ioredis when installed.
 * Production: npm i ioredis && REDIS_URL=redis://localhost:6379
 */

const memory = new Map();
let redis = null;
let mode = 'memory';

const DEFAULT_TTL_MS = Number(process.env.CACHE_TTL_MS) || 60_000;

export async function initCache() {
  const url = process.env.REDIS_URL;
  if (!url) {
    mode = 'memory';
    return mode;
  }
  try {
    // Dynamic import so redis is optional
    const mod = await import('ioredis').catch(() => null);
    if (!mod) {
      console.warn('[cache] REDIS_URL set but ioredis not installed — using memory');
      mode = 'memory';
      return mode;
    }
    redis = new mod.default(url);
    await redis.ping();
    mode = 'redis';
    console.log('[cache] Redis connected');
  } catch (e) {
    console.warn('[cache] Redis unavailable:', e.message, '— using memory');
    mode = 'memory';
    redis = null;
  }
  return mode;
}

export function cacheMode() {
  return mode;
}

export async function cacheGet(key) {
  if (mode === 'redis' && redis) {
    const v = await redis.get(key);
    if (v == null) return null;
    try {
      return JSON.parse(v);
    } catch {
      return v;
    }
  }
  const hit = memory.get(key);
  if (!hit) return null;
  if (hit.exp && Date.now() > hit.exp) {
    memory.delete(key);
    return null;
  }
  return hit.value;
}

export async function cacheSet(key, value, ttlMs = DEFAULT_TTL_MS) {
  if (mode === 'redis' && redis) {
    const sec = Math.max(1, Math.ceil(ttlMs / 1000));
    await redis.set(key, JSON.stringify(value), 'EX', sec);
    return;
  }
  memory.set(key, { value, exp: Date.now() + ttlMs });
}

export async function cacheDel(key) {
  if (mode === 'redis' && redis) {
    await redis.del(key);
    return;
  }
  memory.delete(key);
}

export async function cacheDelPrefix(prefix) {
  if (mode === 'redis' && redis) {
    const keys = await redis.keys(`${prefix}*`);
    if (keys.length) await redis.del(...keys);
    return;
  }
  for (const k of memory.keys()) {
    if (k.startsWith(prefix)) memory.delete(k);
  }
}

/** Memoize async fn with cache */
export function cached(keyFn, ttlMs = DEFAULT_TTL_MS) {
  return function wrap(fn) {
    return async (...args) => {
      const key = typeof keyFn === 'function' ? keyFn(...args) : keyFn;
      const hit = await cacheGet(key);
      if (hit != null) return hit;
      const value = await fn(...args);
      await cacheSet(key, value, ttlMs);
      return value;
    };
  };
}

// periodic memory cleanup
setInterval(() => {
  if (mode !== 'memory') return;
  const now = Date.now();
  for (const [k, v] of memory) {
    if (v.exp && now > v.exp) memory.delete(k);
  }
}, 30_000).unref?.();
