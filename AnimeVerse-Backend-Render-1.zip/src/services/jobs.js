import { getDb } from '../db/connection.js';
import { newId } from '../utils/auth.js';

function startJob(name) {
  const id = newId('job');
  getDb()
    .prepare(`INSERT INTO job_runs (id, job_name, status) VALUES (?, ?, 'running')`)
    .run(id, name);
  return id;
}

function finishJob(id, status, detail) {
  getDb()
    .prepare(
      `UPDATE job_runs SET status = ?, detail_json = ?, finished_at = datetime('now') WHERE id = ?`
    )
    .run(status, JSON.stringify(detail || {}), id);
}

/** Expire offline grants past expires_at */
export function expireOfflineGrants() {
  const id = startJob('expire_offline_grants');
  const db = getDb();
  const result = db
    .prepare(
      `UPDATE offline_grants SET status = 'expired'
       WHERE status IN ('queued','downloading','ready')
         AND expires_at IS NOT NULL
         AND expires_at < datetime('now')`
    )
    .run();
  const detail = { expired: result.changes };
  finishJob(id, 'ok', detail);
  return detail;
}

/** Simulate download progress tick for queued grants */
export function tickDownloadProgress() {
  const id = startJob('tick_download_progress');
  const db = getDb();
  const queued = db
    .prepare(`SELECT id, progress, status FROM offline_grants WHERE status IN ('queued','downloading') LIMIT 50`)
    .all();

  let advanced = 0;
  for (const g of queued) {
    let progress = Number(g.progress) || 0;
    let status = g.status;
    if (status === 'queued') {
      status = 'downloading';
      progress = Math.max(progress, 0.05);
    } else {
      progress = Math.min(1, progress + 0.15 + Math.random() * 0.1);
    }
    if (progress >= 1) {
      progress = 1;
      status = 'ready';
    }
    db.prepare(`UPDATE offline_grants SET progress = ?, status = ? WHERE id = ?`).run(
      progress,
      status,
      g.id
    );
    advanced += 1;
  }
  const detail = { advanced };
  finishJob(id, 'ok', detail);
  return detail;
}

/** Aggregate incomplete progress → soft “continue watching” cache could live here later */
export function healthDeep() {
  const db = getDb();
  const counts = {
    users: db.prepare('SELECT COUNT(*) AS c FROM users').get()?.c ?? 0,
    profiles: db.prepare('SELECT COUNT(*) AS c FROM profiles').get()?.c ?? 0,
    titles: db.prepare('SELECT COUNT(*) AS c FROM titles WHERE published = 1').get()?.c ?? 0,
    episodes: db.prepare('SELECT COUNT(*) AS c FROM episodes').get()?.c ?? 0,
    reviews: db.prepare('SELECT COUNT(*) AS c FROM reviews').get()?.c ?? 0,
    offlineGrants: db.prepare('SELECT COUNT(*) AS c FROM offline_grants').get()?.c ?? 0,
    roomsOpen: db.prepare(`SELECT COUNT(*) AS c FROM watch_rooms WHERE status != 'closed'`).get()?.c ?? 0,
  };
  const recentJobs = db
    .prepare(
      `SELECT job_name AS jobName, status, started_at AS startedAt, finished_at AS finishedAt
       FROM job_runs ORDER BY started_at DESC LIMIT 10`
    )
    .all();
  return {
    ok: true,
    service: 'animeverse-api',
    version: '0.3.0',
    time: new Date().toISOString(),
    database: counts,
    recentJobs,
  };
}

export async function runMaintenance() {
  const expired = expireOfflineGrants();
  const tick = tickDownloadProgress();
  let providers = null;
  try {
    providers = await syncProviderRails();
  } catch (e) {
    providers = { error: e.message };
  }
  return { expired, tick, providers };
}


/** Prefetch trending/airing into cache via providers (safe, limited) */
export async function syncProviderRails() {
  const id = startJob('sync_provider_rails');
  try {
    const { getTrending, getAiring, metadataMode } = await import('../providers/manager.js');
    if (metadataMode() === 'demo') {
      finishJob(id, 'ok', { skipped: true, reason: 'METADATA_MODE=demo' });
      return { skipped: true };
    }
    const [t, a] = await Promise.all([getTrending(12), getAiring(12)]);
    const detail = {
      trending: t.items?.length || 0,
      airing: a.items?.length || 0,
      sources: { trending: t.source, airing: a.source },
    };
    finishJob(id, 'ok', detail);
    return detail;
  } catch (e) {
    finishJob(id, 'error', { message: e.message });
    return { error: e.message };
  }
}

