import { runMaintenance, expireOfflineGrants, tickDownloadProgress } from './jobs.js';

const timers = [];

/**
 * Lightweight in-process scheduler (demo).
 * Production: use system cron, BullMQ, or Cloud Scheduler.
 */
export function startScheduler() {
  const enabled = process.env.SCHEDULER !== '0';
  if (!enabled) {
    console.log('Scheduler disabled (SCHEDULER=0)');
    return;
  }

  const maintenanceMs = Number(process.env.JOB_MAINTENANCE_MS) || 5 * 60 * 1000;
  const tickMs = Number(process.env.JOB_TICK_MS) || 30 * 1000;

  const t1 = setInterval(() => {
    try {
      const r = runMaintenance();
      console.log('[scheduler] maintenance', JSON.stringify(r));
    } catch (e) {
      console.error('[scheduler] maintenance error', e.message);
    }
  }, maintenanceMs);
  t1.unref?.();
  timers.push(t1);

  const t2 = setInterval(() => {
    try {
      tickDownloadProgress();
    } catch (e) {
      console.error('[scheduler] tick error', e.message);
    }
  }, tickMs);
  t2.unref?.();
  timers.push(t2);

  // initial soft pass
  setTimeout(() => {
    try {
      expireOfflineGrants();
    } catch {
      /* schema may not exist yet on first boot before migrate */
    }
  }, 3000).unref?.();

  console.log(
    `Scheduler on — maintenance every ${maintenanceMs}ms, download tick every ${tickMs}ms`
  );
}

export function stopScheduler() {
  for (const t of timers) clearInterval(t);
  timers.length = 0;
}
