import { createHmac, randomBytes } from 'crypto';
import { getDb } from '../db/connection.js';
import { newId } from '../utils/auth.js';

const CDN_BASE = process.env.CDN_BASE_URL || 'https://cdn.animeverse.local/v1';
const CDN_SECRET = process.env.CDN_SIGNING_SECRET || 'animeverse-cdn-dev-secret';
const PACKAGER_SECRET = process.env.PACKAGER_WEBHOOK_SECRET || 'animeverse-packager-dev';

/** HMAC-signed CDN path (demo — not real media) */
export function mintCdnUrl({ path, expiresInSec = 3600 }) {
  const exp = Math.floor(Date.now() / 1000) + expiresInSec;
  const payload = `${path}:${exp}`;
  const sig = createHmac('sha256', CDN_SECRET).update(payload).digest('hex').slice(0, 32);
  const url = `${CDN_BASE}${path}?exp=${exp}&sig=${sig}`;
  return { url, expiresAt: new Date(exp * 1000).toISOString(), path };
}

export function verifyCdnSig(path, exp, sig) {
  if (!exp || !sig) return false;
  if (Number(exp) < Math.floor(Date.now() / 1000)) return false;
  const payload = `${path}:${exp}`;
  const expected = createHmac('sha256', CDN_SECRET).update(payload).digest('hex').slice(0, 32);
  return expected === sig;
}

/** Register or return stub asset for episode */
export function ensureEpisodeAsset(episodeId, quality = '720p') {
  const db = getDb();
  const ep = db
    .prepare('SELECT id, title_id AS titleId FROM episodes WHERE id = ?')
    .get(episodeId);
  if (!ep) return null;

  let row = db
    .prepare(
      `SELECT * FROM cdn_assets WHERE episode_id = ? AND quality = ? AND kind = 'hls' LIMIT 1`
    )
    .get(episodeId, quality);

  if (!row) {
    const id = newId('cdn');
    const path = `/hls/${ep.titleId}/${episodeId}/${quality}/index.m3u8`;
    db.prepare(
      `INSERT INTO cdn_assets (id, title_id, episode_id, kind, quality, path, size_bytes)
       VALUES (?, ?, ?, 'hls', ?, ?, ?)`
    ).run(id, ep.titleId, episodeId, quality, path, 180_000_000);
    row = db.prepare('SELECT * FROM cdn_assets WHERE id = ?').get(id);
  }

  const signed = mintCdnUrl({ path: row.path, expiresInSec: 900 });
  return {
    assetId: row.id,
    kind: row.kind,
    quality: row.quality,
    ...signed,
    note: 'Stub CDN URL — no real stream bytes',
  };
}

export function verifyPackagerSignature(rawBody, signatureHeader) {
  if (!signatureHeader) return false;
  const expected = createHmac('sha256', PACKAGER_SECRET)
    .update(typeof rawBody === 'string' ? rawBody : JSON.stringify(rawBody))
    .digest('hex');
  return signatureHeader === expected || signatureHeader === `sha256=${expected}`;
}

/**
 * Apply packager webhook event to offline_grants status machine.
 * Events: queued | progress | ready | failed | expired
 */
export function applyPackagerEvent({ grantId, eventType, progress, error, assetPath }) {
  const db = getDb();
  const grant = db.prepare('SELECT * FROM offline_grants WHERE id = ?').get(grantId);
  if (!grant) return { ok: false, error: 'Grant not found' };

  const eventId = newId('pevt');
  db.prepare(
    `INSERT INTO packager_events (id, grant_id, event_type, payload_json) VALUES (?, ?, ?, ?)`
  ).run(
    eventId,
    grantId,
    eventType,
    JSON.stringify({ progress, error, assetPath })
  );

  let status = grant.status;
  let prog = grant.progress;

  switch (eventType) {
    case 'queued':
      status = 'queued';
      prog = 0;
      break;
    case 'progress':
      status = 'downloading';
      prog = Math.min(0.99, Number(progress) ?? prog ?? 0.1);
      break;
    case 'ready':
      status = 'ready';
      prog = 1;
      break;
    case 'failed':
      status = 'failed';
      break;
    case 'expired':
      status = 'expired';
      break;
    default:
      return { ok: false, error: `Unknown eventType: ${eventType}` };
  }

  db.prepare(`UPDATE offline_grants SET status = ?, progress = ? WHERE id = ?`).run(
    status,
    prog,
    grantId
  );

  return { ok: true, grantId, status, progress: prog, eventId };
}

/** Simulate packager accepting a grant (called after create) */
export function enqueuePackagerJob(grantId) {
  return applyPackagerEvent({ grantId, eventType: 'queued', progress: 0 });
}
