/**
 * Lightweight metrics (OpenTelemetry-compatible shape without hard dependency).
 * Set OTEL_EXPORTER_OTLP_ENDPOINT to log export intent; install @opentelemetry/* for real export.
 */

const counters = new Map();
const histograms = new Map();
const startedAt = Date.now();

export function inc(name, labels = {}, by = 1) {
  const key = `${name}|${JSON.stringify(labels)}`;
  counters.set(key, (counters.get(key) || 0) + by);
}

export function observe(name, value, labels = {}) {
  const key = `${name}|${JSON.stringify(labels)}`;
  const arr = histograms.get(key) || [];
  arr.push(value);
  if (arr.length > 500) arr.shift();
  histograms.set(key, arr);
}

export function metricsSnapshot() {
  const counterOut = {};
  for (const [k, v] of counters) counterOut[k] = v;

  const histOut = {};
  for (const [k, arr] of histograms) {
    const sorted = [...arr].sort((a, b) => a - b);
    const n = sorted.length;
    histOut[k] = {
      count: n,
      min: n ? sorted[0] : 0,
      max: n ? sorted[n - 1] : 0,
      p50: n ? sorted[Math.floor(n * 0.5)] : 0,
      p95: n ? sorted[Math.floor(n * 0.95)] : 0,
    };
  }

  return {
    uptimeSec: Math.floor((Date.now() - startedAt) / 1000),
    counters: counterOut,
    histograms: histOut,
    otel: {
      endpoint: process.env.OTEL_EXPORTER_OTLP_ENDPOINT || null,
      serviceName: process.env.OTEL_SERVICE_NAME || 'animeverse-api',
      note: process.env.OTEL_EXPORTER_OTLP_ENDPOINT
        ? 'Endpoint configured — install OpenTelemetry SDK to export'
        : 'Set OTEL_EXPORTER_OTLP_ENDPOINT for OTLP export',
    },
  };
}

/** Express middleware */
export function metricsMiddleware(req, res, next) {
  const t0 = Date.now();
  inc('http_requests_total', { method: req.method });
  res.on('finish', () => {
    const ms = Date.now() - t0;
    observe('http_request_duration_ms', ms, {
      method: req.method,
      status: String(res.statusCode),
    });
    inc('http_responses_total', { status: String(res.statusCode) });
  });
  next();
}
