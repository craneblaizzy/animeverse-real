import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { randomUUID, createHash, randomBytes } from 'crypto';

const JWT_SECRET = process.env.JWT_SECRET || 'animeverse-dev-secret-change-me';
const ACCESS_TTL = process.env.JWT_TTL || '2h';
const REFRESH_DAYS = Number(process.env.REFRESH_DAYS) || 30;

export function signAccessToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: ACCESS_TTL });
}

export function verifyAccessToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

export function hashPassword(password) {
  return bcrypt.hashSync(password, 10);
}

export function comparePassword(password, hash) {
  return bcrypt.compareSync(password, hash);
}

export function hashToken(token) {
  return createHash('sha256').update(token).digest('hex');
}

export function newId(prefix = '') {
  return prefix ? `${prefix}_${randomUUID()}` : randomUUID();
}

/** Opaque refresh token (returned once; only hash stored) */
export function issueRefreshToken() {
  return randomBytes(48).toString('base64url');
}

export function refreshExpiresAt() {
  return new Date(Date.now() + REFRESH_DAYS * 24 * 60 * 60 * 1000).toISOString();
}

/** Short-lived playback token (episode-scoped, not a full JWT session) */
export function signPlaybackToken({ userId, profileId, episodeId, titleId }) {
  return jwt.sign(
    { typ: 'playback', sub: userId, profileId, episodeId, titleId },
    JWT_SECRET,
    { expiresIn: '15m' }
  );
}

export function verifyPlaybackToken(token) {
  const payload = jwt.verify(token, JWT_SECRET);
  if (payload.typ !== 'playback') throw new Error('Not a playback token');
  return payload;
}
