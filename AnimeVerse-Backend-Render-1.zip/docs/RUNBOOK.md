# AnimeVerse Backend Runbook

## Local

```bash
cd backend
npm install
npm run db:migrate
npm run db:seed
npm start
```

Demo: `demo@animeverse.local` / `demo1234`

## Environment

| Var | Default | Purpose |
|-----|---------|---------|
| `PORT` | 8787 | HTTP port |
| `JWT_SECRET` | dev secret | **Change in production** |
| `DATABASE_PATH` | `backend/data/animeverse.sqlite` | SQLite file |
| `REDIS_URL` | — | Optional Redis for cache |
| `CACHE_TTL_MS` | 60000 | Default cache TTL |
| `EMAIL_PROVIDER` | console | console \| sendgrid \| ses \| smtp |
| `SENDGRID_API_KEY` | — | When EMAIL_PROVIDER=sendgrid |
| `PACKAGER_SKIP_VERIFY` | — | `1` skips webhook HMAC |
| `PACKAGER_WEBHOOK_SECRET` | dev | HMAC secret |
| `CDN_BASE_URL` | cdn.animeverse.local | CDN prefix |
| `CDN_SIGNING_SECRET` | dev | CDN URL HMAC |
| `SCHEDULER` | on | `0` disables background jobs |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | — | Metrics export intent |
| `GOOGLE_CLIENT_ID` / `APPLE_CLIENT_ID` | — | OAuth |

## Backup / restore

```bash
npm run db:backup
node scripts/backup.js --restore data/backups/animeverse-....sqlite
```

## Load test

```bash
npm start &
npm run test:load        # 20 concurrent × 200 requests
npm run test:load -- 50 500
```

## Postgres path

1. Provision Postgres 16  
2. Apply `migrations/postgres/001_schema.sql` (+ remaining tables from 002–005 adapted)  
3. `npm i pg`  
4. Port `src/db/connection.js` to `pg.Pool` (interface already prepare/run/get/all)  
5. Set `DATABASE_URL`  

## Redis path

```bash
npm i ioredis
REDIS_URL=redis://127.0.0.1:6379 npm start
```

Rails responses are cached ~30s under `rails:<profileId>`.

## Chaos checks

- Kill process mid-request → client retries with refresh token  
- `SCHEDULER=0` → grants won't auto-progress; use packager webhook  
- Invalid JWT → 401  
- Rate limit → 429 after 120 req/min/IP  

## GDPR

- `GET /v1/auth/gdpr/export` — JSON dump  
- `POST /v1/auth/gdpr/delete` with `{ "confirm": "DELETE" }` — soft delete  

## Rights metadata

Admin can attach license windows via `title_rights` table / admin API.


## Live metadata

```bash
METADATA_MODE=live          # or demo
JIKAN_ENABLED=1
TMDB_API_KEY=               # optional
```

- `GET /v1/meta/status` — provider flags
- `GET /v1/search?q=naruto` — live when Jikan up, else demo
- `GET /v1/trending` · `/v1/airing` · `/v1/seasonal`
- Upstream 429/5xx → circuit open → demo fallback (never blank)
