-- Phase 2–3: rooms, activity, admin flags, password reset, franchise links

PRAGMA foreign_keys = ON;

-- Watch party rooms (signaling metadata only — no WebRTC media)
CREATE TABLE IF NOT EXISTS watch_rooms (
  id TEXT PRIMARY KEY,
  host_profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title_id TEXT NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  episode_id TEXT,
  code TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','live','closed')),
  max_guests INTEGER NOT NULL DEFAULT 8,
  meta_json TEXT DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  closed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_rooms_code ON watch_rooms(code);
CREATE INDEX IF NOT EXISTS idx_rooms_host ON watch_rooms(host_profile_id);

CREATE TABLE IF NOT EXISTS watch_room_members (
  room_id TEXT NOT NULL REFERENCES watch_rooms(id) ON DELETE CASCADE,
  profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'guest' CHECK (role IN ('host','guest')),
  joined_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (room_id, profile_id)
);

-- Social activity feed (opt-in style events)
CREATE TABLE IF NOT EXISTS activity_events (
  id TEXT PRIMARY KEY,
  actor_profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  title_id TEXT REFERENCES titles(id) ON DELETE SET NULL,
  meta_json TEXT DEFAULT '{}',
  visibility TEXT NOT NULL DEFAULT 'friends' CHECK (visibility IN ('public','friends','private')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_activity_actor ON activity_events(actor_profile_id);
CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_events(created_at);

-- Franchise / related title graph
CREATE TABLE IF NOT EXISTS title_relations (
  from_title_id TEXT NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  to_title_id TEXT NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  relation TEXT NOT NULL DEFAULT 'related' CHECK (relation IN ('sequel','prequel','spinoff','related','same_franchise')),
  PRIMARY KEY (from_title_id, to_title_id, relation)
);

-- Password reset tokens (hashed)
CREATE TABLE IF NOT EXISTS password_resets (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_pwreset_user ON password_resets(user_id);

-- Email verification tokens
CREATE TABLE IF NOT EXISTS email_verifications (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Admin role flag on users (simple)
-- SQLite: add column if missing via try
-- users.role TEXT DEFAULT 'user'

-- Job runs log
CREATE TABLE IF NOT EXISTS job_runs (
  id TEXT PRIMARY KEY,
  job_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ok',
  detail_json TEXT DEFAULT '{}',
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at TEXT
);
