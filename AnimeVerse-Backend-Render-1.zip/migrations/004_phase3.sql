-- Phase 3: friends graph, packager events, CDN assets

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS follows (
  follower_profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  following_profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (follower_profile_id, following_profile_id),
  CHECK (follower_profile_id != following_profile_id)
);

CREATE INDEX IF NOT EXISTS idx_follows_following ON follows(following_profile_id);

-- Packager / download pipeline events (webhook log)
CREATE TABLE IF NOT EXISTS packager_events (
  id TEXT PRIMARY KEY,
  grant_id TEXT REFERENCES offline_grants(id) ON DELETE SET NULL,
  event_type TEXT NOT NULL,
  payload_json TEXT DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_packager_grant ON packager_events(grant_id);

-- CDN asset registry (stub URLs only)
CREATE TABLE IF NOT EXISTS cdn_assets (
  id TEXT PRIMARY KEY,
  title_id TEXT REFERENCES titles(id) ON DELETE CASCADE,
  episode_id TEXT REFERENCES episodes(id) ON DELETE SET NULL,
  kind TEXT NOT NULL DEFAULT 'hls' CHECK (kind IN ('hls','dash','poster','subtitle')),
  quality TEXT DEFAULT '720p',
  path TEXT NOT NULL,
  size_bytes INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_cdn_episode ON cdn_assets(episode_id);

-- users.email_verified flag (SQLite-friendly: separate table already has tokens)
CREATE TABLE IF NOT EXISTS user_flags (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  email_verified INTEGER NOT NULL DEFAULT 0,
  marketing_opt_in INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
