-- Phase 1–2 schema expansion

PRAGMA foreign_keys = ON;

-- Reviews (spoiler-protected)
CREATE TABLE IF NOT EXISTS reviews (
  id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title_id TEXT NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 10),
  body TEXT,
  has_spoilers INTEGER NOT NULL DEFAULT 0,
  moderated INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'visible' CHECK (status IN ('visible','hidden','flagged')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (profile_id, title_id)
);

CREATE INDEX IF NOT EXISTS idx_reviews_title ON reviews(title_id);
CREATE INDEX IF NOT EXISTS idx_reviews_profile ON reviews(profile_id);

-- Radar alerts (per-profile airing notifications)
CREATE TABLE IF NOT EXISTS radar_alerts (
  id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title_id TEXT NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (profile_id, title_id)
);

CREATE INDEX IF NOT EXISTS idx_radar_profile ON radar_alerts(profile_id);

-- Synthetic air schedule for demo calendar (weekday 0=Sun … 6=Sat)
CREATE TABLE IF NOT EXISTS air_schedule (
  id TEXT PRIMARY KEY,
  title_id TEXT NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  weekday INTEGER NOT NULL CHECK (weekday BETWEEN 0 AND 6),
  time_utc TEXT NOT NULL DEFAULT '12:00',
  episode_hint TEXT,
  UNIQUE (title_id, weekday)
);

-- Characters (lightweight demo)
CREATE TABLE IF NOT EXISTS characters (
  id TEXT PRIMARY KEY,
  title_id TEXT NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  role TEXT DEFAULT 'supporting',
  bio TEXT,
  color TEXT
);

CREATE INDEX IF NOT EXISTS idx_characters_title ON characters(title_id);

-- Activity / audit log (minimal)
CREATE TABLE IF NOT EXISTS activity_log (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  profile_id TEXT,
  action TEXT NOT NULL,
  meta_json TEXT DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_activity_user ON activity_log(user_id);
