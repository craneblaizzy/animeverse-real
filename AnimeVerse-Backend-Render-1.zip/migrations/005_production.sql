-- Production hardening fields

PRAGMA foreign_keys = ON;

-- Rights / legal metadata on titles
CREATE TABLE IF NOT EXISTS title_rights (
  title_id TEXT PRIMARY KEY REFERENCES titles(id) ON DELETE CASCADE,
  territory TEXT DEFAULT 'WW',
  license_start TEXT,
  license_end TEXT,
  licensor TEXT,
  window_type TEXT DEFAULT 'svod',
  exclusivity INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- OAuth linked accounts
CREATE TABLE IF NOT EXISTS oauth_accounts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL CHECK (provider IN ('google','apple','discord')),
  provider_user_id TEXT NOT NULL,
  email TEXT,
  raw_json TEXT DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (provider, provider_user_id)
);

CREATE INDEX IF NOT EXISTS idx_oauth_user ON oauth_accounts(user_id);

-- Audit log (security-sensitive actions)
CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  action TEXT NOT NULL,
  resource TEXT,
  ip TEXT,
  meta_json TEXT DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);
