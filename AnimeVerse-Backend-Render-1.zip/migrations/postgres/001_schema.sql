-- AnimeVerse Postgres target schema (reference)
-- Apply when DATABASE_URL=postgres://... is used with a Postgres driver.
-- Types mapped from SQLite TEXT/INTEGER.

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  locale TEXT DEFAULT 'en',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS profiles (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  avatar_color TEXT,
  is_kids BOOLEAN NOT NULL DEFAULT FALSE,
  pin_hash TEXT,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS titles (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  alt_title TEXT,
  type TEXT NOT NULL DEFAULT 'series',
  year INT,
  status TEXT,
  rating REAL DEFAULT 0,
  episodes INT DEFAULT 1,
  runtime INT DEFAULT 24,
  studio_name TEXT,
  description TEXT,
  poster_gradient TEXT,
  backdrop_gradient TEXT,
  season_label TEXT,
  tone TEXT,
  pacing TEXT,
  themes_json JSONB DEFAULT '[]',
  published BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS episodes (
  id TEXT PRIMARY KEY,
  title_id TEXT NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  season_number INT NOT NULL DEFAULT 1,
  episode_number INT NOT NULL,
  name TEXT,
  runtime INT DEFAULT 24,
  intro_start_ms INT,
  intro_end_ms INT,
  air_date DATE,
  UNIQUE (title_id, season_number, episode_number)
);

CREATE TABLE IF NOT EXISTS watch_progress (
  profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  episode_id TEXT NOT NULL REFERENCES episodes(id) ON DELETE CASCADE,
  position_ms INT NOT NULL DEFAULT 0,
  duration_ms INT,
  completed BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (profile_id, episode_id)
);

CREATE TABLE IF NOT EXISTS watchlist (
  profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title_id TEXT NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (profile_id, title_id)
);

-- See SQLite migrations 001–005 for full parity tables (reviews, rooms, oauth, rights, …)
-- Production checklist:
--   1. npm i pg
--   2. DATABASE_URL=postgres://user:pass@host:5432/animeverse
--   3. Port connection.js to use pg Pool with same prepare-style helpers
--   4. Run this schema + remaining CREATE TABLEs from 002–005 adapted to Postgres types
