-- External metadata providers (Jikan / TMDB) — does not replace local catalog

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS title_external_ids (
  title_id TEXT NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  provider TEXT NOT NULL CHECK (provider IN ('mal','jikan','tmdb','anilist','demo')),
  external_id TEXT NOT NULL,
  PRIMARY KEY (title_id, provider),
  UNIQUE (provider, external_id)
);

CREATE INDEX IF NOT EXISTS idx_ext_provider ON title_external_ids(provider, external_id);

CREATE TABLE IF NOT EXISTS title_images (
  title_id TEXT PRIMARY KEY REFERENCES titles(id) ON DELETE CASCADE,
  poster_url TEXT,
  backdrop_url TEXT,
  logo_url TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS title_meta (
  title_id TEXT PRIMARY KEY REFERENCES titles(id) ON DELETE CASCADE,
  source TEXT DEFAULT 'demo',
  source_updated_at TEXT,
  local_updated_at TEXT,
  manually_edited INTEGER NOT NULL DEFAULT 0,
  popularity REAL DEFAULT 0,
  trailer_url TEXT,
  trailer_type TEXT,
  raw_json TEXT
);

CREATE TABLE IF NOT EXISTS provider_cache_meta (
  cache_key TEXT PRIMARY KEY,
  provider TEXT NOT NULL,
  fetched_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT
);
