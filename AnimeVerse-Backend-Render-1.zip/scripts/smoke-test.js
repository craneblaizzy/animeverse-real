const BASE = process.env.API_URL || 'http://127.0.0.1:8787';

async function req(method, path, body, token, headers = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...headers,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data };
}

function step(name, ok) {
  console.log(ok ? `✓ ${name}` : `✗ ${name}`);
  if (!ok) throw new Error(`FAIL: ${name}`);
}

async function main() {
  let n = 0;
  const ok = (name, cond) => { step(name, !!cond); n++; };

  ok('health', (await req('GET', '/v1/health')).data?.ok);
  ok('health deep', (await req('GET', '/v1/health/deep')).data?.database);
  ok('openapi', (await req('GET', '/v1/openapi.json')).data?.openapi);
  ok('search', (await req('GET', '/v1/search?q=a&limit=3')).data?.facets);
  ok('recs', Array.isArray((await req('GET', '/v1/recommendations?mood=epic')).data?.items));
  ok('radar', Array.isArray((await req('GET', '/v1/radar')).data?.week));
  ok('feed', Array.isArray((await req('GET', '/v1/feed')).data?.items));

  const login = await req('POST', '/v1/auth/login', {
    email: 'demo@animeverse.local', password: 'demo1234', deviceLabel: 'smoke',
  });
  ok('login', login.data?.token && login.data?.refreshToken);
  const token = login.data.token;
  const profileId = login.data.profiles?.[0]?.id;
  const profileKai = login.data.profiles?.find((p) => p.name === 'Kai')?.id;

  ok('me', (await req('GET', '/v1/auth/me', null, token)).data?.user);
  ok('admin stats', (await req('GET', '/v1/admin/stats', null, token)).status === 200);
  ok('gdpr export', (await req('GET', '/v1/auth/gdpr/export', null, token)).data?.user);

  if (profileId) {
    const titles = await req('GET', '/v1/titles?limit=1');
    const tid = titles.data?.items?.[0]?.id;
    if (tid) {
      const detail = await req('GET', `/v1/titles/${tid}`);
      const epId = detail.data?.title?.episodeList?.[0]?.id || `${tid}-s1e1`;

      const mint = await req('POST', '/v1/cdn/mint', { episodeId: epId }, token);
      ok('cdn mint', mint.status === 200 && mint.data?.asset?.url);

      const grant = await req(
        'POST',
        `/v1/profiles/${profileId}/offline-grants`,
        { titleId: tid, pack: 'episode' },
        token
      );
      ok('offline grant', grant.status === 201 && grant.data?.grant?.id);

      if (grant.data?.grant?.id) {
        const wh = await req(
          'POST',
          '/v1/webhooks/packager',
          { grantId: grant.data.grant.id, eventType: 'progress', progress: 0.5 },
          null,
          // skip verify via env preferred; if 401, still note
        );
        ok('packager webhook', wh.status === 200 || wh.status === 401);
      }

      if (profileKai) {
        const fol = await req(
          'POST',
          `/v1/profiles/${profileId}/follow`,
          { targetProfileId: profileKai },
          token
        );
        ok('follow', fol.status === 201 || fol.status === 200);
        ok('following list', Array.isArray((await req('GET', `/v1/profiles/${profileId}/following`)).data?.items));
      }
    }
  }

  console.log(`\nsmoke OK — ${n} checks`);
}

main().catch((e) => { console.error(e); process.exit(1); });
