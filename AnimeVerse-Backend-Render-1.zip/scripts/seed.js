/**
 * Seed SQLite from frontend data/mock.js (fictional catalog only).
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createHash, randomUUID } from 'crypto';
import bcrypt from 'bcryptjs';
import { getDb, getDbPath } from '../src/db/connection.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const mockPath = path.resolve(__dirname, '../../data/mock.js');

function loadMock() {
  const src = fs.readFileSync(mockPath, 'utf8');
  const sandbox = { module: { exports: {} }, exports: {} };
  // mock.js uses const CATALOG / GENRES at top level — evaluate in Function scope
  const fn = new Function(
    'exports',
    'module',
    `${src}\n; return { CATALOG: typeof CATALOG !== 'undefined' ? CATALOG : [], GENRES: typeof GENRES !== 'undefined' ? GENRES : [], STUDIOS: typeof STUDIOS !== 'undefined' ? STUDIOS : [], NOTIFICATIONS: typeof NOTIFICATIONS !== 'undefined' ? NOTIFICATIONS : [] };`
  );
  return fn(sandbox.exports, sandbox.module);
}

const mock = loadMock();
const db = getDb();

const genreId = (name) =>
  name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'genre';

const seed = db.transaction(() => {
  // Demo user
  const userId = 'user-demo';
  const hash = bcrypt.hashSync('demo1234', 10);
  db.prepare(
    `INSERT OR REPLACE INTO users (id, email, password_hash, display_name) VALUES (?, ?, ?, ?)`
  ).run(userId, 'demo@animeverse.local', hash, 'Demo User');

  const profiles = [
    { id: 'profile-aria', name: 'Aria', kids: 0, color: 'linear-gradient(135deg,#6E7CF6,#a78bfa)', order: 0 },
    { id: 'profile-kai', name: 'Kai', kids: 0, color: 'linear-gradient(135deg,#2dd4bf,#0ea5e9)', order: 1 },
    { id: 'profile-kids', name: 'Kids', kids: 1, color: 'linear-gradient(135deg,#34d399,#fbbf24)', order: 2 },
  ];
  for (const p of profiles) {
    db.prepare(
      `INSERT OR REPLACE INTO profiles (id, user_id, name, avatar_color, is_kids, sort_order) VALUES (?, ?, ?, ?, ?, ?)`
    ).run(p.id, userId, p.name, p.color, p.kids, p.order);
    db.prepare(
      `INSERT OR REPLACE INTO profile_settings (profile_id, settings_json) VALUES (?, ?)`
    ).run(p.id, JSON.stringify({ cellWarn: true, autoplay: false, reduceMotion: false, accent: 'default' }));
  }

  // Genres
  for (const g of mock.GENRES || []) {
    const id = g.id || genreId(g.name);
    db.prepare(`INSERT OR REPLACE INTO genres (id, name, color) VALUES (?, ?, ?)`).run(
      id,
      g.name,
      g.color || null
    );
  }

  // Studios
  for (const s of mock.STUDIOS || []) {
    db.prepare(`INSERT OR REPLACE INTO studios (id, name) VALUES (?, ?)`).run(s.id, s.name);
  }

  const insertTitle = db.prepare(`
    INSERT OR REPLACE INTO titles (
      id, title, alt_title, type, year, status, rating, episodes, runtime,
      studio_name, description, poster_gradient, backdrop_gradient, season_label, tone, pacing, themes_json, published
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
  `);
  const insertTg = db.prepare(
    `INSERT OR IGNORE INTO title_genres (title_id, genre_id) VALUES (?, ?)`
  );
  const insertEp = db.prepare(`
    INSERT OR REPLACE INTO episodes (id, title_id, season_number, episode_number, name, runtime)
    VALUES (?, ?, 1, ?, ?, ?)
  `);

  for (const t of mock.CATALOG || []) {
    insertTitle.run(
      t.id,
      t.title,
      t.altTitle || null,
      t.type || 'series',
      t.year || null,
      t.status || 'Completed',
      t.rating || 0,
      t.episodes || 1,
      t.runtime || 24,
      t.studio || null,
      t.description || null,
      t.posterGradient || null,
      t.backdropGradient || null,
      t.season || null,
      t.tone || null,
      t.pacing || null,
      JSON.stringify(t.themes || [])
    );

    for (const gName of t.genres || []) {
      const gid = genreId(gName);
      db.prepare(`INSERT OR IGNORE INTO genres (id, name) VALUES (?, ?)`).run(gid, gName);
      insertTg.run(t.id, gid);
    }

    const epCount = Math.min(t.episodes || 1, 24);
    for (let i = 1; i <= epCount; i++) {
      insertEp.run(`${t.id}-s1e${i}`, t.id, i, `Episode ${i}`, t.runtime || 24);
    }

    // Sample progress on first profile for titles with progress
    if (t.progress > 0 && t.progress < 1) {
      const epNum = Math.max(1, Math.ceil(t.progress * epCount));
      const epId = `${t.id}-s1e${epNum}`;
      const pos = Math.floor((t.progress % (1 / epCount)) * (t.runtime || 24) * 60 * 1000);
      db.prepare(
        `INSERT OR REPLACE INTO watch_progress (profile_id, episode_id, position_ms, duration_ms, completed)
         VALUES ('profile-aria', ?, ?, ?, 0)`
      ).run(epId, pos, (t.runtime || 24) * 60 * 1000);
    }
  }


  // Air schedule for airing titles (spread across week)
  const airing = (mock.CATALOG || []).filter((t) => t.status === 'Airing');
  airing.forEach((t, i) => {
    const weekday = (i * 2) % 7;
    db.prepare(
      `INSERT OR REPLACE INTO air_schedule (id, title_id, weekday, time_utc, episode_hint)
       VALUES (?, ?, ?, ?, ?)`
    ).run(`air-${t.id}`, t.id, weekday, `${10 + (i % 8)}:00`, 'New episode');
  });

  // Sample characters for first few titles
  const sampleChars = [
    { title: 'nebula-odyssey', name: 'Kael Voss', role: 'protagonist', bio: 'Rogue navigator with a forbidden star map.', color: '#6E7CF6' },
    { title: 'nebula-odyssey', name: 'Lyra Chen', role: 'supporting', bio: 'Fleet strategist torn between duty and discovery.', color: '#a78bfa' },
    { title: 'cherry-blossom-code', name: 'Hana Mori', role: 'protagonist', bio: 'Software engineer returning to Kyoto.', color: '#f472b6' },
    { title: 'shadow-protocol', name: 'Ryo', role: 'protagonist', bio: 'Black-ops operative with erased memories.', color: '#64748b' },
  ];
  for (const c of sampleChars) {
    const exists = db.prepare('SELECT id FROM titles WHERE id = ?').get(c.title);
    if (!exists) continue;
    db.prepare(
      `INSERT OR REPLACE INTO characters (id, title_id, name, role, bio, color) VALUES (?, ?, ?, ?, ?, ?)`
    ).run(`char-${c.title}-${c.name.toLowerCase().replace(/\s+/g, '-')}`, c.title, c.name, c.role, c.bio, c.color);
  }

  // Sample review
  const firstTitle = (mock.CATALOG || [])[0];
  if (firstTitle) {
    db.prepare(
      `INSERT OR REPLACE INTO reviews (id, profile_id, title_id, rating, body, has_spoilers)
       VALUES ('rev-demo-1', 'profile-aria', ?, 9, 'Cinematic world-building with real emotional stakes. Episode 7 hit hard.', 1)`
    ).run(firstTitle.id);
  }

  // Demo radar alert
  if (airing[0]) {
    db.prepare(
      `INSERT OR REPLACE INTO radar_alerts (id, profile_id, title_id, enabled) VALUES ('radar-demo-1', 'profile-aria', ?, 1)`
    ).run(airing[0].id);
  }

  // Demo notifications
  for (const n of mock.NOTIFICATIONS || []) {
    db.prepare(
      `INSERT OR REPLACE INTO notifications (id, user_id, title, body, unread) VALUES (?, ?, ?, ?, ?)`
    ).run(n.id || randomUUID(), userId, n.title, n.body || '', n.unread ? 1 : 0);
  }


  // Franchise relations (demo graph)
  const rels = [
    ['nebula-odyssey', 'shadow-protocol', 'related'],
    ['cherry-blossom-code', 'nebula-odyssey', 'related'],
  ];
  for (const [a, b, rel] of rels) {
    const ta = db.prepare('SELECT id FROM titles WHERE id = ?').get(a);
    const tb = db.prepare('SELECT id FROM titles WHERE id = ?').get(b);
    if (ta && tb) {
      db.prepare(
        `INSERT OR IGNORE INTO title_relations (from_title_id, to_title_id, relation) VALUES (?, ?, ?)`
      ).run(a, b, rel);
    }
  }

  // Sample activity
  const first = (mock.CATALOG || [])[0];
  if (first) {
    db.prepare(
      `INSERT OR REPLACE INTO activity_events (id, actor_profile_id, type, title_id, meta_json, visibility)
       VALUES ('act-demo-1', 'profile-aria', 'watched', ?, '{"episode":1}', 'public')`
    ).run(first.id);
  }


  // Demo follow graph
  try {
    db.prepare(
      `INSERT OR IGNORE INTO follows (follower_profile_id, following_profile_id) VALUES ('profile-aria', 'profile-kai')`
    ).run();
    db.prepare(
      `INSERT OR IGNORE INTO follows (follower_profile_id, following_profile_id) VALUES ('profile-kai', 'profile-aria')`
    ).run();
  } catch (e) { /* migration 004 may not be applied yet in same run */ }

  console.log('Seeded titles:', (mock.CATALOG || []).length);
  console.log('Demo login: demo@animeverse.local / demo1234');
});

seed();
console.log('Database:', getDbPath());
