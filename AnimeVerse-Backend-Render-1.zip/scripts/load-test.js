/**
 * Simple concurrent load test against a running API.
 * Usage: node scripts/load-test.js [concurrency=20] [requests=200]
 */
const BASE = process.env.API_URL || 'http://127.0.0.1:8787';
const concurrency = Number(process.argv[2]) || 20;
const total = Number(process.argv[3]) || 200;

const paths = [
  '/v1/health',
  '/v1/titles?limit=10',
  '/v1/search?q=a&limit=5',
  '/v1/recommendations?mood=epic',
  '/v1/radar',
  '/v1/rails',
  '/v1/genres',
  '/v1/openapi.json',
];

async function one() {
  const path = paths[Math.floor(Math.random() * paths.length)];
  const t0 = Date.now();
  try {
    const res = await fetch(`${BASE}${path}`);
    return { ok: res.ok, status: res.status, ms: Date.now() - t0, path };
  } catch (e) {
    return { ok: false, status: 0, ms: Date.now() - t0, path, error: e.message };
  }
}

async function main() {
  console.log(`Load test ${BASE} — concurrency=${concurrency} total=${total}`);
  const results = [];
  let launched = 0;

  async function worker() {
    while (launched < total) {
      launched += 1;
      results.push(await one());
    }
  }

  const t0 = Date.now();
  await Promise.all(Array.from({ length: concurrency }, () => worker()));
  const elapsed = Date.now() - t0;

  const ok = results.filter((r) => r.ok).length;
  const fail = results.length - ok;
  const times = results.map((r) => r.ms).sort((a, b) => a - b);
  const p50 = times[Math.floor(times.length * 0.5)] || 0;
  const p95 = times[Math.floor(times.length * 0.95)] || 0;
  const rps = ((results.length / elapsed) * 1000).toFixed(1);

  console.log({
    total: results.length,
    ok,
    fail,
    elapsedMs: elapsed,
    rps: Number(rps),
    p50ms: p50,
    p95ms: p95,
    maxMs: times[times.length - 1] || 0,
  });

  if (fail > total * 0.05) {
    console.error('Failure rate > 5%');
    process.exit(1);
  }
  console.log('load-test OK');
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
