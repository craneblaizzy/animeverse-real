/**
 * SQLite backup / restore helpers.
 * Usage:
 *   node scripts/backup.js
 *   node scripts/backup.js --restore path/to/backup.sqlite
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { getDb, getDbPath } from '../src/db/connection.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const backupDir = path.resolve(__dirname, '../data/backups');
if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });

const restorePath = process.argv.includes('--restore')
  ? process.argv[process.argv.indexOf('--restore') + 1]
  : null;

if (restorePath) {
  if (!fs.existsSync(restorePath)) {
    console.error('Backup file not found:', restorePath);
    process.exit(1);
  }
  const dest = getDbPath();
  try {
    getDb().close();
  } catch {
    /* */
  }
  for (const suffix of ['', '-wal', '-shm']) {
    const f = dest + suffix;
    if (fs.existsSync(f)) fs.unlinkSync(f);
  }
  fs.copyFileSync(restorePath, dest);
  console.log('Restored', restorePath, '→', dest);
  console.log('Re-run: npm start');
  process.exit(0);
}

const src = getDbPath();
if (!fs.existsSync(src)) {
  console.error('No database at', src, '— run migrate/seed first');
  process.exit(1);
}

// Checkpoint WAL into main file for consistent copy
try {
  getDb().exec('PRAGMA wal_checkpoint(TRUNCATE)');
} catch (e) {
  console.warn('checkpoint:', e.message);
}

const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const dest = path.join(backupDir, `animeverse-${stamp}.sqlite`);
fs.copyFileSync(src, dest);
const size = fs.statSync(dest).size;
console.log('Backup written:', dest, `(${size} bytes)`);
console.log('Restore: node scripts/backup.js --restore', dest);
